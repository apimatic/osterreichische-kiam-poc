# Public User

```ruby
public_user_api = client.public_user
```

## Class Name

`PublicUserApi`


# Create User

```ruby
def create_user(captcha_token: nil,
                body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captcha_token` | `String` | Header, Optional | - |
| `body` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

This method returns a `ApiResponse` instance.

## Example Usage

```ruby
result = public_user_api.create_user
```

