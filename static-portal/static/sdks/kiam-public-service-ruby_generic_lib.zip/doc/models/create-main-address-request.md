
# Create Main Address Request

## Structure

`CreateMainAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_iso_alpha_2_code` | `String` | Optional | - |
| `postal_code` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `street` | `String` | Optional | - |
| `street_2` | `String` | Optional | - |
| `door_number` | `String` | Optional | - |
| `house_number` | `String` | Optional | - |
| `post_address_code` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code8",
  "postalCode": "postalCode6",
  "city": "city8",
  "street": "street2",
  "street2": "street22"
}
```

