
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_type` | `Integer` | Optional | - |
| `country_iso_alpha_2_code` | `String` | Optional | - |
| `postal_code` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `street` | `String` | Optional | - |
| `street_2` | `String` | Optional | - |
| `door_number` | `String` | Optional | - |
| `house_number` | `String` | Optional | - |
| `post_address_code` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

