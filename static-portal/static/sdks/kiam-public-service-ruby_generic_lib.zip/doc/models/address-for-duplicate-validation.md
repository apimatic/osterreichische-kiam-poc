
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_iso_alpha_2_code` | `String` | Optional | - |
| `postal_code` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `street` | `String` | Optional | - |
| `door_number` | `String` | Optional | - |
| `house_number` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

