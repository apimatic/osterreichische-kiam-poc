
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `password` | `String` | Optional | - |
| `username` | `String` | Optional | - |
| `salutation` | `String` | Optional | - |
| `firstname` | `String` | Optional | - |
| `lastname` | `String` | Optional | - |
| `birthdate` | `DateTime` | Optional | - |
| `title_before_name` | `String` | Optional | - |
| `title_after_name` | `String` | Optional | - |
| `phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `addresses` | [`Array<CreateAddressRequest>`](../../doc/models/create-address-request.md) | Optional | - |
| `registration_succeeded_callback_url` | `String` | Optional | - |
| `registration_origin` | `String` | Optional | - |
| `marketing_agreement` | `TrueClass \| FalseClass` | Optional | - |
| `newsletter` | `TrueClass \| FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

