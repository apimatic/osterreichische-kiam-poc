
# Registration Confirmation Response

## Structure

`RegistrationConfirmationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callback_url` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "callbackUrl": "callbackUrl4"
}
```

