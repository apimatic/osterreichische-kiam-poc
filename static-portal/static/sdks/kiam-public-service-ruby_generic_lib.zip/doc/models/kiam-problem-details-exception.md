
# Kiam Problem Details Exception

*This model accepts additional fields of type Object.*

## Structure

`KiamProblemDetailsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | - |
| `title` | `String` | Optional | - |
| `status` | `Integer` | Optional | - |
| `detail` | `String` | Optional | - |
| `instance` | `String` | Optional | - |
| `error` | [`LegacyErrorInfo`](../../doc/models/legacy-error-info.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "type8",
  "title": "title2",
  "status": 200,
  "detail": "detail8",
  "instance": "instance8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

