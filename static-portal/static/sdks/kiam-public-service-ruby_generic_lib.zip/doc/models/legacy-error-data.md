
# Legacy Error Data

## Structure

`LegacyErrorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | - |
| `value` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4"
}
```

