
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_code` | `String` | Optional | - |
| `area_code` | `String` | Optional | - |
| `number` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

