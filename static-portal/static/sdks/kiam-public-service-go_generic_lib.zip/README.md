
# Getting Started with Kiam Public Service

## Introduction

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the kiamPublicService library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace kiamPublicService => ".\\kiam-public-service-go_generic_lib" // local path to the SDK

require kiamPublicService v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `httpConfiguration` | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| `loggerConfiguration` | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
client := kiamPublicService.NewClient(
    kiamPublicService.CreateConfiguration(
        kiamPublicService.WithHttpConfiguration(
            kiamPublicService.CreateHttpConfiguration(
                kiamPublicService.WithTimeout(0),
            ),
        ),
        kiamPublicService.WithLoggerConfiguration(
            kiamPublicService.WithLevel("info"),
            kiamPublicService.WithRequestConfiguration(
                kiamPublicService.WithRequestBody(true),
            ),
            kiamPublicService.WithResponseConfiguration(
                kiamPublicService.WithResponseHeaders(true),
            ),
        ),
    ),
)
```

## List of APIs

* [Company](doc/controllers/company.md)
* [Double Opt In](doc/controllers/double-opt-in.md)
* [Public User](doc/controllers/public-user.md)
* [Validations](doc/controllers/validations.md)

## Classes Documentation

* [HttpConfiguration](doc/http-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)

