
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `httpConfiguration` | [`HttpConfiguration`](http-configuration.md) | Configurable http client options like timeout and retries. |
| `loggerConfiguration` | [`LoggerConfiguration`](logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
client := kiamPublicService.NewClient(
    kiamPublicService.CreateConfiguration(
        kiamPublicService.WithHttpConfiguration(
            kiamPublicService.CreateHttpConfiguration(
                kiamPublicService.WithTimeout(0),
            ),
        ),
        kiamPublicService.WithLoggerConfiguration(
            kiamPublicService.WithLevel("info"),
            kiamPublicService.WithRequestConfiguration(
                kiamPublicService.WithRequestBody(true),
            ),
            kiamPublicService.WithResponseConfiguration(
                kiamPublicService.WithResponseHeaders(true),
            ),
        ),
    ),
)
```

## Kiam Public Service Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| CompanyApi() | Gets CompanyApi |
| DoubleOptInApi() | Gets DoubleOptInApi |
| PublicUserApi() | Gets PublicUserApi |
| ValidationsApi() | Gets ValidationsApi |

