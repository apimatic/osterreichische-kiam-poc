
# Confirm Registration Request

## Structure

`ConfirmRegistrationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `models.Optional[string]` | Optional | - |
| `ApplicationName` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "token": "token4",
  "applicationName": "applicationName6"
}
```

