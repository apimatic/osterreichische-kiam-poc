
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Password` | `models.Optional[string]` | Optional | - |
| `Username` | `models.Optional[string]` | Optional | - |
| `Salutation` | `models.Optional[string]` | Optional | - |
| `Firstname` | `models.Optional[string]` | Optional | - |
| `Lastname` | `models.Optional[string]` | Optional | - |
| `Birthdate` | `models.Optional[time.Time]` | Optional | - |
| `TitleBeforeName` | `models.Optional[string]` | Optional | - |
| `TitleAfterName` | `models.Optional[string]` | Optional | - |
| `Phone` | [`*models.Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Mobile` | [`*models.Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Addresses` | [`models.Optional[[]models.CreateAddressRequest]`](../../doc/models/create-address-request.md) | Optional | - |
| `RegistrationSucceededCallbackUrl` | `models.Optional[string]` | Optional | - |
| `RegistrationOrigin` | `models.Optional[string]` | Optional | - |
| `MarketingAgreement` | `models.Optional[bool]` | Optional | - |
| `Newsletter` | `models.Optional[bool]` | Optional | - |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

