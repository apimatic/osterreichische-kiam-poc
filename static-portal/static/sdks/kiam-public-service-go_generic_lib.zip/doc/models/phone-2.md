
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryCode` | `models.Optional[string]` | Optional | - |
| `AreaCode` | `models.Optional[string]` | Optional | - |
| `Number` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

