
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AddressType` | `models.Optional[int]` | Optional | - |
| `CountryIsoAlpha2Code` | `models.Optional[string]` | Optional | - |
| `PostalCode` | `models.Optional[string]` | Optional | - |
| `City` | `models.Optional[string]` | Optional | - |
| `Street` | `models.Optional[string]` | Optional | - |
| `Street2` | `models.Optional[string]` | Optional | - |
| `DoorNumber` | `models.Optional[string]` | Optional | - |
| `HouseNumber` | `models.Optional[string]` | Optional | - |
| `PostAddressCode` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

