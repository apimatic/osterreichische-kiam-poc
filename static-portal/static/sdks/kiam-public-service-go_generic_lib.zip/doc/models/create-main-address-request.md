
# Create Main Address Request

## Structure

`CreateMainAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryIsoAlpha2Code` | `models.Optional[string]` | Optional | - |
| `PostalCode` | `models.Optional[string]` | Optional | - |
| `City` | `models.Optional[string]` | Optional | - |
| `Street` | `models.Optional[string]` | Optional | - |
| `Street2` | `models.Optional[string]` | Optional | - |
| `DoorNumber` | `models.Optional[string]` | Optional | - |
| `HouseNumber` | `models.Optional[string]` | Optional | - |
| `PostAddressCode` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code8",
  "postalCode": "postalCode6",
  "city": "city8",
  "street": "street2",
  "street2": "street22"
}
```

