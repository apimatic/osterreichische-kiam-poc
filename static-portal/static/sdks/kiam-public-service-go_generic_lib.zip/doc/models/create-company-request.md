
# Create Company Request

## Structure

`CreateCompanyRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `User` | [`*models.CreateUserRequest`](../../doc/models/create-user-request.md) | Optional | - |
| `CompanyName` | `models.Optional[string]` | Optional | - |
| `EmailAddress` | `models.Optional[string]` | Optional | - |
| `Phone` | [`*models.Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Mobile` | [`*models.Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `MainAddress` | [`*models.CreateMainAddressRequest`](../../doc/models/create-main-address-request.md) | Optional | - |
| `RegistrationSucceededCallbackUrl` | `models.Optional[string]` | Optional | - |
| `Uid` | `models.Optional[string]` | Optional | - |
| `LegalFormId` | `models.Optional[int]` | Optional | - |
| `OrganizationNumber` | `models.Optional[string]` | Optional | - |
| `SapDebitor` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "user": {
    "password": "password4",
    "username": "username0",
    "salutation": "salutation4",
    "firstname": "firstname8",
    "lastname": "lastname6"
  },
  "companyName": "companyName6",
  "emailAddress": "emailAddress4",
  "phone": {
    "countryCode": "countryCode4",
    "areaCode": "areaCode2",
    "number": "number8"
  },
  "mobile": {
    "countryCode": "countryCode0",
    "areaCode": "areaCode6",
    "number": "number8"
  }
}
```

