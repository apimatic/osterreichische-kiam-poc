
# Legacy Error Info

## Structure

`LegacyErrorInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `models.Optional[string]` | Optional | - |
| `Message` | `models.Optional[string]` | Optional | - |
| `Target` | `models.Optional[string]` | Optional | - |
| `Data` | [`models.Optional[[]models.LegacyErrorData]`](../../doc/models/legacy-error-data.md) | Optional | - |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0",
  "target": "target8",
  "data": [
    {
      "name": "name0",
      "value": "value2"
    }
  ]
}
```

