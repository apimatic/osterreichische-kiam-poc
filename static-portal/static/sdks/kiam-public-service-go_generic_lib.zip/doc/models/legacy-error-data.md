
# Legacy Error Data

## Structure

`LegacyErrorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `models.Optional[string]` | Optional | - |
| `Value` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4"
}
```

