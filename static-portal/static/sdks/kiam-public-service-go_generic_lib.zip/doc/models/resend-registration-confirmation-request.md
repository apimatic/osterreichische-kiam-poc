
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Username` | `models.Optional[string]` | Optional | - |
| `ApplicationName` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

