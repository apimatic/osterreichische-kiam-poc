
# String Field Value

## Structure

`StringFieldValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Value` | `models.Optional[string]` | Optional | - |

## Example (as JSON)

```json
{
  "value": "value2"
}
```

