# Public User

```go
publicUserApi := client.PublicUserApi()
```

## Class Name

`PublicUserApi`


# Create User

```go
CreateUser(
    ctx context.Context,
    captchaToken *string,
    body *models.CreateUserRequest) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captchaToken` | `*string` | Header, Optional | - |
| `body` | [`*models.CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

``

## Example Usage

```go
ctx := context.Background()





resp, err := publicUserApi.CreateUser(ctx, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

