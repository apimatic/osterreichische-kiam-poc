# Validations

```go
validationsApi := client.ValidationsApi()
```

## Class Name

`ValidationsApi`

## Methods

* [Validate Username](../../doc/controllers/validations.md#validate-username)
* [Validate for Duplicate User](../../doc/controllers/validations.md#validate-for-duplicate-user)


# Validate Username

```go
ValidateUsername(
    ctx context.Context,
    body *models.StringFieldValue) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.StringFieldValue`](../../doc/models/string-field-value.md) | Body, Optional | - |

## Response Type

``

## Example Usage

```go
ctx := context.Background()



resp, err := validationsApi.ValidateUsername(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | - | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Validate for Duplicate User

```go
ValidateForDuplicateUser(
    ctx context.Context,
    body *models.ValidateForDuplicateUserRequest) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.ValidateForDuplicateUserRequest`](../../doc/models/validate-for-duplicate-user-request.md) | Body, Optional | - |

## Response Type

``

## Example Usage

```go
ctx := context.Background()



resp, err := validationsApi.ValidateForDuplicateUser(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Validation error code is duplicate_user | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |

