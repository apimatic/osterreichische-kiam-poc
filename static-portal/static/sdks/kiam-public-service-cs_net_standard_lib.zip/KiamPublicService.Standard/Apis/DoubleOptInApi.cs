// <copyright file="DoubleOptInApi.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Exceptions;
using KiamPublicService.Standard.Http.Client;
using KiamPublicService.Standard.Http.Response;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace KiamPublicService.Standard.Apis
{
    /// <summary>
    /// DoubleOptInApi.
    /// </summary>
    public class DoubleOptInApi : BaseApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DoubleOptInApi"/> class.
        /// </summary>
        internal DoubleOptInApi(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// ResendRegistrationConfirmation EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Request with username (email address) of the user..</param>
        public void ResendRegistrationConfirmation(
                Models.ResendRegistrationConfirmationRequest body = null)
            => CoreHelper.RunVoidTask(ResendRegistrationConfirmationAsync(body));

        /// <summary>
        /// ResendRegistrationConfirmation EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Request with username (email address) of the user..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ResendRegistrationConfirmationAsync(
                Models.ResendRegistrationConfirmationRequest body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/doubleOptIn/initiate")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("404", CreateErrorCase("User with username was not found.", (_reason, _context) => new KiamProblemDetailsException(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("An error occurred", (_reason, _context) => new KiamProblemDetailsException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// ConfirmRegistration EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the ApiResponse of Models.RegistrationConfirmationResponse response from the API call.</returns>
        public ApiResponse<Models.RegistrationConfirmationResponse> ConfirmRegistration(
                Models.ConfirmRegistrationRequest body = null)
            => CoreHelper.RunTask(ConfirmRegistrationAsync(body));

        /// <summary>
        /// ConfirmRegistration EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the ApiResponse of Models.RegistrationConfirmationResponse response from the API call.</returns>
        public async Task<ApiResponse<Models.RegistrationConfirmationResponse>> ConfirmRegistrationAsync(
                Models.ConfirmRegistrationRequest body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.RegistrationConfirmationResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/doubleOptIn/confirm")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}