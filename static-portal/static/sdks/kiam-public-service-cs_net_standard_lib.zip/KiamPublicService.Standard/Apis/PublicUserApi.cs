// <copyright file="PublicUserApi.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Http.Client;
using KiamPublicService.Standard.Http.Response;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace KiamPublicService.Standard.Apis
{
    /// <summary>
    /// PublicUserApi.
    /// </summary>
    public class PublicUserApi : BaseApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PublicUserApi"/> class.
        /// </summary>
        internal PublicUserApi(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// CreateUser EndPoint.
        /// </summary>
        /// <param name="captchaToken">Optional parameter: Example: .</param>
        /// <param name="body">Optional parameter: Example: .</param>
        public void CreateUser(
                string captchaToken = null,
                Models.CreateUserRequest body = null)
            => CoreHelper.RunVoidTask(CreateUserAsync(captchaToken, body));

        /// <summary>
        /// CreateUser EndPoint.
        /// </summary>
        /// <param name="captchaToken">Optional parameter: Example: .</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateUserAsync(
                string captchaToken = null,
                Models.CreateUserRequest body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/users")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("captchaToken", captchaToken))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}