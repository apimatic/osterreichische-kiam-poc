// <copyright file="ValidationsApi.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Exceptions;
using KiamPublicService.Standard.Http.Client;
using KiamPublicService.Standard.Http.Response;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace KiamPublicService.Standard.Apis
{
    /// <summary>
    /// ValidationsApi.
    /// </summary>
    public class ValidationsApi : BaseApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationsApi"/> class.
        /// </summary>
        internal ValidationsApi(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// ValidateUsername EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        public void ValidateUsername(
                Models.StringFieldValue body = null)
            => CoreHelper.RunVoidTask(ValidateUsernameAsync(body));

        /// <summary>
        /// ValidateUsername EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ValidateUsernameAsync(
                Models.StringFieldValue body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/validations/validateUsername")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("", (_reason, _context) => new KiamProblemDetailsException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// ValidateForDuplicateUser EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        public void ValidateForDuplicateUser(
                Models.ValidateForDuplicateUserRequest body = null)
            => CoreHelper.RunVoidTask(ValidateForDuplicateUserAsync(body));

        /// <summary>
        /// ValidateForDuplicateUser EndPoint.
        /// </summary>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ValidateForDuplicateUserAsync(
                Models.ValidateForDuplicateUserRequest body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/validations/validateDuplicateUser")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Validation error code is duplicate_user", (_reason, _context) => new KiamProblemDetailsException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}