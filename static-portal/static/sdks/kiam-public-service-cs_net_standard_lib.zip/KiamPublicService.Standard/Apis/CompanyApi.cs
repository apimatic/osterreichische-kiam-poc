// <copyright file="CompanyApi.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Exceptions;
using KiamPublicService.Standard.Http.Client;
using KiamPublicService.Standard.Http.Response;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace KiamPublicService.Standard.Apis
{
    /// <summary>
    /// CompanyApi.
    /// </summary>
    public class CompanyApi : BaseApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyApi"/> class.
        /// </summary>
        internal CompanyApi(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// CreateCompanyWithBusinessUser EndPoint.
        /// </summary>
        /// <param name="captchaToken">Optional parameter: This parameter is used to provide the captcha specific value for a token, solution or how else a parameter is called in a captcha solution..</param>
        /// <param name="body">Optional parameter: Data of the newly created company and related user.               User salutation can have values M or W, M means male and W means female, X means other.               Possible values for users' address type: 1 or 2. 1 means main address, 2 means secondary address.               If password is not defined or is null, created user will receive an e-mail and will have to set password using received link..</param>
        public void CreateCompanyWithBusinessUser(
                string captchaToken = null,
                Models.CreateCompanyRequest body = null)
            => CoreHelper.RunVoidTask(CreateCompanyWithBusinessUserAsync(captchaToken, body));

        /// <summary>
        /// CreateCompanyWithBusinessUser EndPoint.
        /// </summary>
        /// <param name="captchaToken">Optional parameter: This parameter is used to provide the captcha specific value for a token, solution or how else a parameter is called in a captcha solution..</param>
        /// <param name="body">Optional parameter: Data of the newly created company and related user.               User salutation can have values M or W, M means male and W means female, X means other.               Possible values for users' address type: 1 or 2. 1 means main address, 2 means secondary address.               If password is not defined or is null, created user will receive an e-mail and will have to set password using received link..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateCompanyWithBusinessUserAsync(
                string captchaToken = null,
                Models.CreateCompanyRequest body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/companies")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("captchaToken", captchaToken))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Invalid request.\r\n            \r\n             Usual invalid request response format:\r\n             Error code is validation_error. Information about the error can be found in the details field.\r\n             Target describes which field is invalid, validation error code defines the more detailed validation error case.\r\n             There could be multiple errors per field. See example response.\r\n            \r\n             List of error codes in format [error code] - [optional description] - [fields which can have this validation error] for user fields and company fields:\r\n            \r\n             Company fields\r\n            \r\n             required - company_name\r\n             invalid - company_legal_form_id, company_email_address, company_phone_country_code, company_phone_area_code, company_phone_number, company_mobile_country_code, company_mobile_area_code, company_mobile_number, company_countryIsoAlpha2Code\r\n            \r\n             User fields\r\n             \r\n             required -  Required field. - username, first_name, last_name, registration_origin\r\n             username_not_available - Username is already taken. - username\r\n             too_short - The input value is too short. - username, first_name, last_name\r\n             too_long - The input value is too long. - username, first_name, last_name\r\n             no_titles_allowed - No titles allowed, E.g. BSc. - first_name, last_name\r\n             no_company_types_allowed - No company types allowed. E.g. GmbH. - first_name, last_name\r\n             person_too_young - Person with specified birthdate is too young. - birthdate\r\n             invalid - first_name, last_name, username, phone_country_code, phone_area_code, phone_number, mobile_country_code, mobile_area_code, mobile_number, user_addressX_countryIsoAlpha2Code (where X is the index of the address in the array, starting from 0, e.G. user_address0_countryIsoAlpha2Code)\r\n             new_password_invalid - the new password is invalid - password\r\n             captcha_error - Invalid Captcha token.", (_reason, _context) => new ApiException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}