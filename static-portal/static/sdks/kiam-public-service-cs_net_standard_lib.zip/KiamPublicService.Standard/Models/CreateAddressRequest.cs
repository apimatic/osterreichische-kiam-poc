// <copyright file="CreateAddressRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// CreateAddressRequest.
    /// </summary>
    public class CreateAddressRequest
    {
        private int? addressType;
        private string countryIsoAlpha2Code;
        private string postalCode;
        private string city;
        private string street;
        private string street2;
        private string doorNumber;
        private string houseNumber;
        private string postAddressCode;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "addressType", false },
            { "countryIsoAlpha2Code", false },
            { "postalCode", false },
            { "city", false },
            { "street", false },
            { "street2", false },
            { "doorNumber", false },
            { "houseNumber", false },
            { "postAddressCode", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateAddressRequest"/> class.
        /// </summary>
        public CreateAddressRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateAddressRequest"/> class.
        /// </summary>
        /// <param name="addressType">addressType.</param>
        /// <param name="countryIsoAlpha2Code">countryIsoAlpha2Code.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="city">city.</param>
        /// <param name="street">street.</param>
        /// <param name="street2">street2.</param>
        /// <param name="doorNumber">doorNumber.</param>
        /// <param name="houseNumber">houseNumber.</param>
        /// <param name="postAddressCode">postAddressCode.</param>
        public CreateAddressRequest(
            int? addressType = null,
            string countryIsoAlpha2Code = null,
            string postalCode = null,
            string city = null,
            string street = null,
            string street2 = null,
            string doorNumber = null,
            string houseNumber = null,
            string postAddressCode = null)
        {

            if (addressType != null)
            {
                this.AddressType = addressType;
            }

            if (countryIsoAlpha2Code != null)
            {
                this.CountryIsoAlpha2Code = countryIsoAlpha2Code;
            }

            if (postalCode != null)
            {
                this.PostalCode = postalCode;
            }

            if (city != null)
            {
                this.City = city;
            }

            if (street != null)
            {
                this.Street = street;
            }

            if (street2 != null)
            {
                this.Street2 = street2;
            }

            if (doorNumber != null)
            {
                this.DoorNumber = doorNumber;
            }

            if (houseNumber != null)
            {
                this.HouseNumber = houseNumber;
            }

            if (postAddressCode != null)
            {
                this.PostAddressCode = postAddressCode;
            }
        }

        /// <summary>
        /// Gets or sets AddressType.
        /// </summary>
        [JsonProperty("addressType")]
        public int? AddressType
        {
            get
            {
                return this.addressType;
            }

            set
            {
                this.shouldSerialize["addressType"] = true;
                this.addressType = value;
            }
        }

        /// <summary>
        /// Gets or sets CountryIsoAlpha2Code.
        /// </summary>
        [JsonProperty("countryIsoAlpha2Code")]
        public string CountryIsoAlpha2Code
        {
            get
            {
                return this.countryIsoAlpha2Code;
            }

            set
            {
                this.shouldSerialize["countryIsoAlpha2Code"] = true;
                this.countryIsoAlpha2Code = value;
            }
        }

        /// <summary>
        /// Gets or sets PostalCode.
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode
        {
            get
            {
                return this.postalCode;
            }

            set
            {
                this.shouldSerialize["postalCode"] = true;
                this.postalCode = value;
            }
        }

        /// <summary>
        /// Gets or sets City.
        /// </summary>
        [JsonProperty("city")]
        public string City
        {
            get
            {
                return this.city;
            }

            set
            {
                this.shouldSerialize["city"] = true;
                this.city = value;
            }
        }

        /// <summary>
        /// Gets or sets Street.
        /// </summary>
        [JsonProperty("street")]
        public string Street
        {
            get
            {
                return this.street;
            }

            set
            {
                this.shouldSerialize["street"] = true;
                this.street = value;
            }
        }

        /// <summary>
        /// Gets or sets Street2.
        /// </summary>
        [JsonProperty("street2")]
        public string Street2
        {
            get
            {
                return this.street2;
            }

            set
            {
                this.shouldSerialize["street2"] = true;
                this.street2 = value;
            }
        }

        /// <summary>
        /// Gets or sets DoorNumber.
        /// </summary>
        [JsonProperty("doorNumber")]
        public string DoorNumber
        {
            get
            {
                return this.doorNumber;
            }

            set
            {
                this.shouldSerialize["doorNumber"] = true;
                this.doorNumber = value;
            }
        }

        /// <summary>
        /// Gets or sets HouseNumber.
        /// </summary>
        [JsonProperty("houseNumber")]
        public string HouseNumber
        {
            get
            {
                return this.houseNumber;
            }

            set
            {
                this.shouldSerialize["houseNumber"] = true;
                this.houseNumber = value;
            }
        }

        /// <summary>
        /// Gets or sets PostAddressCode.
        /// </summary>
        [JsonProperty("postAddressCode")]
        public string PostAddressCode
        {
            get
            {
                return this.postAddressCode;
            }

            set
            {
                this.shouldSerialize["postAddressCode"] = true;
                this.postAddressCode = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CreateAddressRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetAddressType()
        {
            this.shouldSerialize["addressType"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetCountryIsoAlpha2Code()
        {
            this.shouldSerialize["countryIsoAlpha2Code"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetPostalCode()
        {
            this.shouldSerialize["postalCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetCity()
        {
            this.shouldSerialize["city"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetStreet()
        {
            this.shouldSerialize["street"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetStreet2()
        {
            this.shouldSerialize["street2"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetDoorNumber()
        {
            this.shouldSerialize["doorNumber"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetHouseNumber()
        {
            this.shouldSerialize["houseNumber"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetPostAddressCode()
        {
            this.shouldSerialize["postAddressCode"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddressType()
        {
            return this.shouldSerialize["addressType"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCountryIsoAlpha2Code()
        {
            return this.shouldSerialize["countryIsoAlpha2Code"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePostalCode()
        {
            return this.shouldSerialize["postalCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCity()
        {
            return this.shouldSerialize["city"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeStreet()
        {
            return this.shouldSerialize["street"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeStreet2()
        {
            return this.shouldSerialize["street2"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeDoorNumber()
        {
            return this.shouldSerialize["doorNumber"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeHouseNumber()
        {
            return this.shouldSerialize["houseNumber"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePostAddressCode()
        {
            return this.shouldSerialize["postAddressCode"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CreateAddressRequest other &&
                (this.AddressType == null && other.AddressType == null ||
                 this.AddressType?.Equals(other.AddressType) == true) &&
                (this.CountryIsoAlpha2Code == null && other.CountryIsoAlpha2Code == null ||
                 this.CountryIsoAlpha2Code?.Equals(other.CountryIsoAlpha2Code) == true) &&
                (this.PostalCode == null && other.PostalCode == null ||
                 this.PostalCode?.Equals(other.PostalCode) == true) &&
                (this.City == null && other.City == null ||
                 this.City?.Equals(other.City) == true) &&
                (this.Street == null && other.Street == null ||
                 this.Street?.Equals(other.Street) == true) &&
                (this.Street2 == null && other.Street2 == null ||
                 this.Street2?.Equals(other.Street2) == true) &&
                (this.DoorNumber == null && other.DoorNumber == null ||
                 this.DoorNumber?.Equals(other.DoorNumber) == true) &&
                (this.HouseNumber == null && other.HouseNumber == null ||
                 this.HouseNumber?.Equals(other.HouseNumber) == true) &&
                (this.PostAddressCode == null && other.PostAddressCode == null ||
                 this.PostAddressCode?.Equals(other.PostAddressCode) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"AddressType = {(this.AddressType == null ? "null" : this.AddressType.ToString())}");
            toStringOutput.Add($"CountryIsoAlpha2Code = {this.CountryIsoAlpha2Code ?? "null"}");
            toStringOutput.Add($"PostalCode = {this.PostalCode ?? "null"}");
            toStringOutput.Add($"City = {this.City ?? "null"}");
            toStringOutput.Add($"Street = {this.Street ?? "null"}");
            toStringOutput.Add($"Street2 = {this.Street2 ?? "null"}");
            toStringOutput.Add($"DoorNumber = {this.DoorNumber ?? "null"}");
            toStringOutput.Add($"HouseNumber = {this.HouseNumber ?? "null"}");
            toStringOutput.Add($"PostAddressCode = {this.PostAddressCode ?? "null"}");
        }
    }
}