// <copyright file="CreateUserRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// CreateUserRequest.
    /// </summary>
    public class CreateUserRequest
    {
        private string password;
        private string username;
        private string salutation;
        private string firstname;
        private string lastname;
        private DateTime? birthdate;
        private string titleBeforeName;
        private string titleAfterName;
        private List<Models.CreateAddressRequest> addresses;
        private string registrationSucceededCallbackUrl;
        private string registrationOrigin;
        private bool? marketingAgreement;
        private bool? newsletter;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "password", false },
            { "username", false },
            { "salutation", false },
            { "firstname", false },
            { "lastname", false },
            { "birthdate", false },
            { "titleBeforeName", false },
            { "titleAfterName", false },
            { "addresses", false },
            { "registrationSucceededCallbackUrl", false },
            { "registrationOrigin", false },
            { "marketingAgreement", false },
            { "newsletter", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateUserRequest"/> class.
        /// </summary>
        public CreateUserRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateUserRequest"/> class.
        /// </summary>
        /// <param name="password">password.</param>
        /// <param name="username">username.</param>
        /// <param name="salutation">salutation.</param>
        /// <param name="firstname">firstname.</param>
        /// <param name="lastname">lastname.</param>
        /// <param name="birthdate">birthdate.</param>
        /// <param name="titleBeforeName">titleBeforeName.</param>
        /// <param name="titleAfterName">titleAfterName.</param>
        /// <param name="phone">phone.</param>
        /// <param name="mobile">mobile.</param>
        /// <param name="addresses">addresses.</param>
        /// <param name="registrationSucceededCallbackUrl">registrationSucceededCallbackUrl.</param>
        /// <param name="registrationOrigin">registrationOrigin.</param>
        /// <param name="marketingAgreement">marketingAgreement.</param>
        /// <param name="newsletter">newsletter.</param>
        public CreateUserRequest(
            string password = null,
            string username = null,
            string salutation = null,
            string firstname = null,
            string lastname = null,
            DateTime? birthdate = null,
            string titleBeforeName = null,
            string titleAfterName = null,
            Models.Phone2 phone = null,
            Models.Phone2 mobile = null,
            List<Models.CreateAddressRequest> addresses = null,
            string registrationSucceededCallbackUrl = null,
            string registrationOrigin = null,
            bool? marketingAgreement = null,
            bool? newsletter = null)
        {

            if (password != null)
            {
                this.Password = password;
            }

            if (username != null)
            {
                this.Username = username;
            }

            if (salutation != null)
            {
                this.Salutation = salutation;
            }

            if (firstname != null)
            {
                this.Firstname = firstname;
            }

            if (lastname != null)
            {
                this.Lastname = lastname;
            }

            if (birthdate != null)
            {
                this.Birthdate = birthdate;
            }

            if (titleBeforeName != null)
            {
                this.TitleBeforeName = titleBeforeName;
            }

            if (titleAfterName != null)
            {
                this.TitleAfterName = titleAfterName;
            }
            this.Phone = phone;
            this.Mobile = mobile;

            if (addresses != null)
            {
                this.Addresses = addresses;
            }

            if (registrationSucceededCallbackUrl != null)
            {
                this.RegistrationSucceededCallbackUrl = registrationSucceededCallbackUrl;
            }

            if (registrationOrigin != null)
            {
                this.RegistrationOrigin = registrationOrigin;
            }

            if (marketingAgreement != null)
            {
                this.MarketingAgreement = marketingAgreement;
            }

            if (newsletter != null)
            {
                this.Newsletter = newsletter;
            }
        }

        /// <summary>
        /// Gets or sets Password.
        /// </summary>
        [JsonProperty("password")]
        public string Password
        {
            get
            {
                return this.password;
            }

            set
            {
                this.shouldSerialize["password"] = true;
                this.password = value;
            }
        }

        /// <summary>
        /// Gets or sets Username.
        /// </summary>
        [JsonProperty("username")]
        public string Username
        {
            get
            {
                return this.username;
            }

            set
            {
                this.shouldSerialize["username"] = true;
                this.username = value;
            }
        }

        /// <summary>
        /// Gets or sets Salutation.
        /// </summary>
        [JsonProperty("salutation")]
        public string Salutation
        {
            get
            {
                return this.salutation;
            }

            set
            {
                this.shouldSerialize["salutation"] = true;
                this.salutation = value;
            }
        }

        /// <summary>
        /// Gets or sets Firstname.
        /// </summary>
        [JsonProperty("firstname")]
        public string Firstname
        {
            get
            {
                return this.firstname;
            }

            set
            {
                this.shouldSerialize["firstname"] = true;
                this.firstname = value;
            }
        }

        /// <summary>
        /// Gets or sets Lastname.
        /// </summary>
        [JsonProperty("lastname")]
        public string Lastname
        {
            get
            {
                return this.lastname;
            }

            set
            {
                this.shouldSerialize["lastname"] = true;
                this.lastname = value;
            }
        }

        /// <summary>
        /// Gets or sets Birthdate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("birthdate")]
        public DateTime? Birthdate
        {
            get
            {
                return this.birthdate;
            }

            set
            {
                this.shouldSerialize["birthdate"] = true;
                this.birthdate = value;
            }
        }

        /// <summary>
        /// Gets or sets TitleBeforeName.
        /// </summary>
        [JsonProperty("titleBeforeName")]
        public string TitleBeforeName
        {
            get
            {
                return this.titleBeforeName;
            }

            set
            {
                this.shouldSerialize["titleBeforeName"] = true;
                this.titleBeforeName = value;
            }
        }

        /// <summary>
        /// Gets or sets TitleAfterName.
        /// </summary>
        [JsonProperty("titleAfterName")]
        public string TitleAfterName
        {
            get
            {
                return this.titleAfterName;
            }

            set
            {
                this.shouldSerialize["titleAfterName"] = true;
                this.titleAfterName = value;
            }
        }

        /// <summary>
        /// Gets or sets Phone.
        /// </summary>
        [JsonProperty("phone", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Phone2 Phone { get; set; }

        /// <summary>
        /// Gets or sets Mobile.
        /// </summary>
        [JsonProperty("mobile", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Phone2 Mobile { get; set; }

        /// <summary>
        /// Gets or sets Addresses.
        /// </summary>
        [JsonProperty("addresses")]
        public List<Models.CreateAddressRequest> Addresses
        {
            get
            {
                return this.addresses;
            }

            set
            {
                this.shouldSerialize["addresses"] = true;
                this.addresses = value;
            }
        }

        /// <summary>
        /// Gets or sets RegistrationSucceededCallbackUrl.
        /// </summary>
        [JsonProperty("registrationSucceededCallbackUrl")]
        public string RegistrationSucceededCallbackUrl
        {
            get
            {
                return this.registrationSucceededCallbackUrl;
            }

            set
            {
                this.shouldSerialize["registrationSucceededCallbackUrl"] = true;
                this.registrationSucceededCallbackUrl = value;
            }
        }

        /// <summary>
        /// Gets or sets RegistrationOrigin.
        /// </summary>
        [JsonProperty("registrationOrigin")]
        public string RegistrationOrigin
        {
            get
            {
                return this.registrationOrigin;
            }

            set
            {
                this.shouldSerialize["registrationOrigin"] = true;
                this.registrationOrigin = value;
            }
        }

        /// <summary>
        /// Gets or sets MarketingAgreement.
        /// </summary>
        [JsonProperty("marketingAgreement")]
        public bool? MarketingAgreement
        {
            get
            {
                return this.marketingAgreement;
            }

            set
            {
                this.shouldSerialize["marketingAgreement"] = true;
                this.marketingAgreement = value;
            }
        }

        /// <summary>
        /// Gets or sets Newsletter.
        /// </summary>
        [JsonProperty("newsletter")]
        public bool? Newsletter
        {
            get
            {
                return this.newsletter;
            }

            set
            {
                this.shouldSerialize["newsletter"] = true;
                this.newsletter = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CreateUserRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetPassword()
        {
            this.shouldSerialize["password"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetUsername()
        {
            this.shouldSerialize["username"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetSalutation()
        {
            this.shouldSerialize["salutation"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetFirstname()
        {
            this.shouldSerialize["firstname"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetLastname()
        {
            this.shouldSerialize["lastname"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetBirthdate()
        {
            this.shouldSerialize["birthdate"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetTitleBeforeName()
        {
            this.shouldSerialize["titleBeforeName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetTitleAfterName()
        {
            this.shouldSerialize["titleAfterName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetAddresses()
        {
            this.shouldSerialize["addresses"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetRegistrationSucceededCallbackUrl()
        {
            this.shouldSerialize["registrationSucceededCallbackUrl"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetRegistrationOrigin()
        {
            this.shouldSerialize["registrationOrigin"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetMarketingAgreement()
        {
            this.shouldSerialize["marketingAgreement"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetNewsletter()
        {
            this.shouldSerialize["newsletter"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePassword()
        {
            return this.shouldSerialize["password"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeUsername()
        {
            return this.shouldSerialize["username"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeSalutation()
        {
            return this.shouldSerialize["salutation"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeFirstname()
        {
            return this.shouldSerialize["firstname"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeLastname()
        {
            return this.shouldSerialize["lastname"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeBirthdate()
        {
            return this.shouldSerialize["birthdate"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeTitleBeforeName()
        {
            return this.shouldSerialize["titleBeforeName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeTitleAfterName()
        {
            return this.shouldSerialize["titleAfterName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddresses()
        {
            return this.shouldSerialize["addresses"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeRegistrationSucceededCallbackUrl()
        {
            return this.shouldSerialize["registrationSucceededCallbackUrl"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeRegistrationOrigin()
        {
            return this.shouldSerialize["registrationOrigin"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeMarketingAgreement()
        {
            return this.shouldSerialize["marketingAgreement"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeNewsletter()
        {
            return this.shouldSerialize["newsletter"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CreateUserRequest other &&
                (this.Password == null && other.Password == null ||
                 this.Password?.Equals(other.Password) == true) &&
                (this.Username == null && other.Username == null ||
                 this.Username?.Equals(other.Username) == true) &&
                (this.Salutation == null && other.Salutation == null ||
                 this.Salutation?.Equals(other.Salutation) == true) &&
                (this.Firstname == null && other.Firstname == null ||
                 this.Firstname?.Equals(other.Firstname) == true) &&
                (this.Lastname == null && other.Lastname == null ||
                 this.Lastname?.Equals(other.Lastname) == true) &&
                (this.Birthdate == null && other.Birthdate == null ||
                 this.Birthdate?.Equals(other.Birthdate) == true) &&
                (this.TitleBeforeName == null && other.TitleBeforeName == null ||
                 this.TitleBeforeName?.Equals(other.TitleBeforeName) == true) &&
                (this.TitleAfterName == null && other.TitleAfterName == null ||
                 this.TitleAfterName?.Equals(other.TitleAfterName) == true) &&
                (this.Phone == null && other.Phone == null ||
                 this.Phone?.Equals(other.Phone) == true) &&
                (this.Mobile == null && other.Mobile == null ||
                 this.Mobile?.Equals(other.Mobile) == true) &&
                (this.Addresses == null && other.Addresses == null ||
                 this.Addresses?.Equals(other.Addresses) == true) &&
                (this.RegistrationSucceededCallbackUrl == null && other.RegistrationSucceededCallbackUrl == null ||
                 this.RegistrationSucceededCallbackUrl?.Equals(other.RegistrationSucceededCallbackUrl) == true) &&
                (this.RegistrationOrigin == null && other.RegistrationOrigin == null ||
                 this.RegistrationOrigin?.Equals(other.RegistrationOrigin) == true) &&
                (this.MarketingAgreement == null && other.MarketingAgreement == null ||
                 this.MarketingAgreement?.Equals(other.MarketingAgreement) == true) &&
                (this.Newsletter == null && other.Newsletter == null ||
                 this.Newsletter?.Equals(other.Newsletter) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Password = {this.Password ?? "null"}");
            toStringOutput.Add($"Username = {this.Username ?? "null"}");
            toStringOutput.Add($"Salutation = {this.Salutation ?? "null"}");
            toStringOutput.Add($"Firstname = {this.Firstname ?? "null"}");
            toStringOutput.Add($"Lastname = {this.Lastname ?? "null"}");
            toStringOutput.Add($"Birthdate = {(this.Birthdate == null ? "null" : this.Birthdate.ToString())}");
            toStringOutput.Add($"TitleBeforeName = {this.TitleBeforeName ?? "null"}");
            toStringOutput.Add($"TitleAfterName = {this.TitleAfterName ?? "null"}");
            toStringOutput.Add($"Phone = {(this.Phone == null ? "null" : this.Phone.ToString())}");
            toStringOutput.Add($"Mobile = {(this.Mobile == null ? "null" : this.Mobile.ToString())}");
            toStringOutput.Add($"Addresses = {(this.Addresses == null ? "null" : $"[{string.Join(", ", this.Addresses)} ]")}");
            toStringOutput.Add($"RegistrationSucceededCallbackUrl = {this.RegistrationSucceededCallbackUrl ?? "null"}");
            toStringOutput.Add($"RegistrationOrigin = {this.RegistrationOrigin ?? "null"}");
            toStringOutput.Add($"MarketingAgreement = {(this.MarketingAgreement == null ? "null" : this.MarketingAgreement.ToString())}");
            toStringOutput.Add($"Newsletter = {(this.Newsletter == null ? "null" : this.Newsletter.ToString())}");
        }
    }
}