// <copyright file="ResendRegistrationConfirmationRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// ResendRegistrationConfirmationRequest.
    /// </summary>
    public class ResendRegistrationConfirmationRequest
    {
        private string username;
        private string applicationName;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "username", false },
            { "applicationName", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ResendRegistrationConfirmationRequest"/> class.
        /// </summary>
        public ResendRegistrationConfirmationRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResendRegistrationConfirmationRequest"/> class.
        /// </summary>
        /// <param name="username">username.</param>
        /// <param name="applicationName">applicationName.</param>
        public ResendRegistrationConfirmationRequest(
            string username = null,
            string applicationName = null)
        {

            if (username != null)
            {
                this.Username = username;
            }

            if (applicationName != null)
            {
                this.ApplicationName = applicationName;
            }
        }

        /// <summary>
        /// Gets or sets Username.
        /// </summary>
        [JsonProperty("username")]
        public string Username
        {
            get
            {
                return this.username;
            }

            set
            {
                this.shouldSerialize["username"] = true;
                this.username = value;
            }
        }

        /// <summary>
        /// Gets or sets ApplicationName.
        /// </summary>
        [JsonProperty("applicationName")]
        public string ApplicationName
        {
            get
            {
                return this.applicationName;
            }

            set
            {
                this.shouldSerialize["applicationName"] = true;
                this.applicationName = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ResendRegistrationConfirmationRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetUsername()
        {
            this.shouldSerialize["username"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetApplicationName()
        {
            this.shouldSerialize["applicationName"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeUsername()
        {
            return this.shouldSerialize["username"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeApplicationName()
        {
            return this.shouldSerialize["applicationName"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ResendRegistrationConfirmationRequest other &&
                (this.Username == null && other.Username == null ||
                 this.Username?.Equals(other.Username) == true) &&
                (this.ApplicationName == null && other.ApplicationName == null ||
                 this.ApplicationName?.Equals(other.ApplicationName) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Username = {this.Username ?? "null"}");
            toStringOutput.Add($"ApplicationName = {this.ApplicationName ?? "null"}");
        }
    }
}