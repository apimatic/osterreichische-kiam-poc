// <copyright file="CreateCompanyRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// CreateCompanyRequest.
    /// </summary>
    public class CreateCompanyRequest
    {
        private string companyName;
        private string emailAddress;
        private string registrationSucceededCallbackUrl;
        private string uid;
        private int? legalFormId;
        private string organizationNumber;
        private string sapDebitor;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "companyName", false },
            { "emailAddress", false },
            { "registrationSucceededCallbackUrl", false },
            { "uid", false },
            { "legalFormId", false },
            { "organizationNumber", false },
            { "sapDebitor", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCompanyRequest"/> class.
        /// </summary>
        public CreateCompanyRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCompanyRequest"/> class.
        /// </summary>
        /// <param name="user">user.</param>
        /// <param name="companyName">companyName.</param>
        /// <param name="emailAddress">emailAddress.</param>
        /// <param name="phone">phone.</param>
        /// <param name="mobile">mobile.</param>
        /// <param name="mainAddress">mainAddress.</param>
        /// <param name="registrationSucceededCallbackUrl">registrationSucceededCallbackUrl.</param>
        /// <param name="uid">uid.</param>
        /// <param name="legalFormId">legalFormId.</param>
        /// <param name="organizationNumber">organizationNumber.</param>
        /// <param name="sapDebitor">sapDebitor.</param>
        public CreateCompanyRequest(
            Models.CreateUserRequest user = null,
            string companyName = null,
            string emailAddress = null,
            Models.Phone2 phone = null,
            Models.Phone2 mobile = null,
            Models.CreateMainAddressRequest mainAddress = null,
            string registrationSucceededCallbackUrl = null,
            string uid = null,
            int? legalFormId = null,
            string organizationNumber = null,
            string sapDebitor = null)
        {
            this.User = user;

            if (companyName != null)
            {
                this.CompanyName = companyName;
            }

            if (emailAddress != null)
            {
                this.EmailAddress = emailAddress;
            }
            this.Phone = phone;
            this.Mobile = mobile;
            this.MainAddress = mainAddress;

            if (registrationSucceededCallbackUrl != null)
            {
                this.RegistrationSucceededCallbackUrl = registrationSucceededCallbackUrl;
            }

            if (uid != null)
            {
                this.Uid = uid;
            }

            if (legalFormId != null)
            {
                this.LegalFormId = legalFormId;
            }

            if (organizationNumber != null)
            {
                this.OrganizationNumber = organizationNumber;
            }

            if (sapDebitor != null)
            {
                this.SapDebitor = sapDebitor;
            }
        }

        /// <summary>
        /// Gets or sets User.
        /// </summary>
        [JsonProperty("user", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CreateUserRequest User { get; set; }

        /// <summary>
        /// Gets or sets CompanyName.
        /// </summary>
        [JsonProperty("companyName")]
        public string CompanyName
        {
            get
            {
                return this.companyName;
            }

            set
            {
                this.shouldSerialize["companyName"] = true;
                this.companyName = value;
            }
        }

        /// <summary>
        /// Gets or sets EmailAddress.
        /// </summary>
        [JsonProperty("emailAddress")]
        public string EmailAddress
        {
            get
            {
                return this.emailAddress;
            }

            set
            {
                this.shouldSerialize["emailAddress"] = true;
                this.emailAddress = value;
            }
        }

        /// <summary>
        /// Gets or sets Phone.
        /// </summary>
        [JsonProperty("phone", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Phone2 Phone { get; set; }

        /// <summary>
        /// Gets or sets Mobile.
        /// </summary>
        [JsonProperty("mobile", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Phone2 Mobile { get; set; }

        /// <summary>
        /// Gets or sets MainAddress.
        /// </summary>
        [JsonProperty("mainAddress", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CreateMainAddressRequest MainAddress { get; set; }

        /// <summary>
        /// Gets or sets RegistrationSucceededCallbackUrl.
        /// </summary>
        [JsonProperty("registrationSucceededCallbackUrl")]
        public string RegistrationSucceededCallbackUrl
        {
            get
            {
                return this.registrationSucceededCallbackUrl;
            }

            set
            {
                this.shouldSerialize["registrationSucceededCallbackUrl"] = true;
                this.registrationSucceededCallbackUrl = value;
            }
        }

        /// <summary>
        /// Gets or sets Uid.
        /// </summary>
        [JsonProperty("uid")]
        public string Uid
        {
            get
            {
                return this.uid;
            }

            set
            {
                this.shouldSerialize["uid"] = true;
                this.uid = value;
            }
        }

        /// <summary>
        /// Gets or sets LegalFormId.
        /// </summary>
        [JsonProperty("legalFormId")]
        public int? LegalFormId
        {
            get
            {
                return this.legalFormId;
            }

            set
            {
                this.shouldSerialize["legalFormId"] = true;
                this.legalFormId = value;
            }
        }

        /// <summary>
        /// Gets or sets OrganizationNumber.
        /// </summary>
        [JsonProperty("organizationNumber")]
        public string OrganizationNumber
        {
            get
            {
                return this.organizationNumber;
            }

            set
            {
                this.shouldSerialize["organizationNumber"] = true;
                this.organizationNumber = value;
            }
        }

        /// <summary>
        /// Gets or sets SapDebitor.
        /// </summary>
        [JsonProperty("sapDebitor")]
        public string SapDebitor
        {
            get
            {
                return this.sapDebitor;
            }

            set
            {
                this.shouldSerialize["sapDebitor"] = true;
                this.sapDebitor = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CreateCompanyRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetCompanyName()
        {
            this.shouldSerialize["companyName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetEmailAddress()
        {
            this.shouldSerialize["emailAddress"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetRegistrationSucceededCallbackUrl()
        {
            this.shouldSerialize["registrationSucceededCallbackUrl"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetUid()
        {
            this.shouldSerialize["uid"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetLegalFormId()
        {
            this.shouldSerialize["legalFormId"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetOrganizationNumber()
        {
            this.shouldSerialize["organizationNumber"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetSapDebitor()
        {
            this.shouldSerialize["sapDebitor"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCompanyName()
        {
            return this.shouldSerialize["companyName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeEmailAddress()
        {
            return this.shouldSerialize["emailAddress"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeRegistrationSucceededCallbackUrl()
        {
            return this.shouldSerialize["registrationSucceededCallbackUrl"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeUid()
        {
            return this.shouldSerialize["uid"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeLegalFormId()
        {
            return this.shouldSerialize["legalFormId"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeOrganizationNumber()
        {
            return this.shouldSerialize["organizationNumber"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeSapDebitor()
        {
            return this.shouldSerialize["sapDebitor"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CreateCompanyRequest other &&
                (this.User == null && other.User == null ||
                 this.User?.Equals(other.User) == true) &&
                (this.CompanyName == null && other.CompanyName == null ||
                 this.CompanyName?.Equals(other.CompanyName) == true) &&
                (this.EmailAddress == null && other.EmailAddress == null ||
                 this.EmailAddress?.Equals(other.EmailAddress) == true) &&
                (this.Phone == null && other.Phone == null ||
                 this.Phone?.Equals(other.Phone) == true) &&
                (this.Mobile == null && other.Mobile == null ||
                 this.Mobile?.Equals(other.Mobile) == true) &&
                (this.MainAddress == null && other.MainAddress == null ||
                 this.MainAddress?.Equals(other.MainAddress) == true) &&
                (this.RegistrationSucceededCallbackUrl == null && other.RegistrationSucceededCallbackUrl == null ||
                 this.RegistrationSucceededCallbackUrl?.Equals(other.RegistrationSucceededCallbackUrl) == true) &&
                (this.Uid == null && other.Uid == null ||
                 this.Uid?.Equals(other.Uid) == true) &&
                (this.LegalFormId == null && other.LegalFormId == null ||
                 this.LegalFormId?.Equals(other.LegalFormId) == true) &&
                (this.OrganizationNumber == null && other.OrganizationNumber == null ||
                 this.OrganizationNumber?.Equals(other.OrganizationNumber) == true) &&
                (this.SapDebitor == null && other.SapDebitor == null ||
                 this.SapDebitor?.Equals(other.SapDebitor) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"User = {(this.User == null ? "null" : this.User.ToString())}");
            toStringOutput.Add($"CompanyName = {this.CompanyName ?? "null"}");
            toStringOutput.Add($"EmailAddress = {this.EmailAddress ?? "null"}");
            toStringOutput.Add($"Phone = {(this.Phone == null ? "null" : this.Phone.ToString())}");
            toStringOutput.Add($"Mobile = {(this.Mobile == null ? "null" : this.Mobile.ToString())}");
            toStringOutput.Add($"MainAddress = {(this.MainAddress == null ? "null" : this.MainAddress.ToString())}");
            toStringOutput.Add($"RegistrationSucceededCallbackUrl = {this.RegistrationSucceededCallbackUrl ?? "null"}");
            toStringOutput.Add($"Uid = {this.Uid ?? "null"}");
            toStringOutput.Add($"LegalFormId = {(this.LegalFormId == null ? "null" : this.LegalFormId.ToString())}");
            toStringOutput.Add($"OrganizationNumber = {this.OrganizationNumber ?? "null"}");
            toStringOutput.Add($"SapDebitor = {this.SapDebitor ?? "null"}");
        }
    }
}