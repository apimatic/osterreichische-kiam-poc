// <copyright file="Phone2.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// Phone2.
    /// </summary>
    public class Phone2
    {
        private string countryCode;
        private string areaCode;
        private string number;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "countryCode", false },
            { "areaCode", false },
            { "number", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="Phone2"/> class.
        /// </summary>
        public Phone2()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Phone2"/> class.
        /// </summary>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="areaCode">areaCode.</param>
        /// <param name="number">number.</param>
        public Phone2(
            string countryCode = null,
            string areaCode = null,
            string number = null)
        {

            if (countryCode != null)
            {
                this.CountryCode = countryCode;
            }

            if (areaCode != null)
            {
                this.AreaCode = areaCode;
            }

            if (number != null)
            {
                this.Number = number;
            }
        }

        /// <summary>
        /// Gets or sets CountryCode.
        /// </summary>
        [JsonProperty("countryCode")]
        public string CountryCode
        {
            get
            {
                return this.countryCode;
            }

            set
            {
                this.shouldSerialize["countryCode"] = true;
                this.countryCode = value;
            }
        }

        /// <summary>
        /// Gets or sets AreaCode.
        /// </summary>
        [JsonProperty("areaCode")]
        public string AreaCode
        {
            get
            {
                return this.areaCode;
            }

            set
            {
                this.shouldSerialize["areaCode"] = true;
                this.areaCode = value;
            }
        }

        /// <summary>
        /// Gets or sets Number.
        /// </summary>
        [JsonProperty("number")]
        public string Number
        {
            get
            {
                return this.number;
            }

            set
            {
                this.shouldSerialize["number"] = true;
                this.number = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Phone2 : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetCountryCode()
        {
            this.shouldSerialize["countryCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetAreaCode()
        {
            this.shouldSerialize["areaCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetNumber()
        {
            this.shouldSerialize["number"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCountryCode()
        {
            return this.shouldSerialize["countryCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAreaCode()
        {
            return this.shouldSerialize["areaCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeNumber()
        {
            return this.shouldSerialize["number"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Phone2 other &&
                (this.CountryCode == null && other.CountryCode == null ||
                 this.CountryCode?.Equals(other.CountryCode) == true) &&
                (this.AreaCode == null && other.AreaCode == null ||
                 this.AreaCode?.Equals(other.AreaCode) == true) &&
                (this.Number == null && other.Number == null ||
                 this.Number?.Equals(other.Number) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"CountryCode = {this.CountryCode ?? "null"}");
            toStringOutput.Add($"AreaCode = {this.AreaCode ?? "null"}");
            toStringOutput.Add($"Number = {this.Number ?? "null"}");
        }
    }
}