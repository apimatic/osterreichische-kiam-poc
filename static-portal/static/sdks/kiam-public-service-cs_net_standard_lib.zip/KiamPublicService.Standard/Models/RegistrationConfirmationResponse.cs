// <copyright file="RegistrationConfirmationResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// RegistrationConfirmationResponse.
    /// </summary>
    public class RegistrationConfirmationResponse
    {
        private string callbackUrl;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "callbackUrl", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="RegistrationConfirmationResponse"/> class.
        /// </summary>
        public RegistrationConfirmationResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RegistrationConfirmationResponse"/> class.
        /// </summary>
        /// <param name="callbackUrl">callbackUrl.</param>
        public RegistrationConfirmationResponse(
            string callbackUrl = null)
        {

            if (callbackUrl != null)
            {
                this.CallbackUrl = callbackUrl;
            }
        }

        /// <summary>
        /// Gets or sets CallbackUrl.
        /// </summary>
        [JsonProperty("callbackUrl")]
        public string CallbackUrl
        {
            get
            {
                return this.callbackUrl;
            }

            set
            {
                this.shouldSerialize["callbackUrl"] = true;
                this.callbackUrl = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"RegistrationConfirmationResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetCallbackUrl()
        {
            this.shouldSerialize["callbackUrl"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCallbackUrl()
        {
            return this.shouldSerialize["callbackUrl"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is RegistrationConfirmationResponse other &&
                (this.CallbackUrl == null && other.CallbackUrl == null ||
                 this.CallbackUrl?.Equals(other.CallbackUrl) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"CallbackUrl = {this.CallbackUrl ?? "null"}");
        }
    }
}