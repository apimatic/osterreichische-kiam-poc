// <copyright file="StringFieldValue.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// StringFieldValue.
    /// </summary>
    public class StringFieldValue
    {
        private string mValue;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "value", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="StringFieldValue"/> class.
        /// </summary>
        public StringFieldValue()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="StringFieldValue"/> class.
        /// </summary>
        /// <param name="mValue">value.</param>
        public StringFieldValue(
            string mValue = null)
        {

            if (mValue != null)
            {
                this.MValue = mValue;
            }
        }

        /// <summary>
        /// Gets or sets MValue.
        /// </summary>
        [JsonProperty("value")]
        public string MValue
        {
            get
            {
                return this.mValue;
            }

            set
            {
                this.shouldSerialize["value"] = true;
                this.mValue = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"StringFieldValue : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetMValue()
        {
            this.shouldSerialize["value"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeMValue()
        {
            return this.shouldSerialize["value"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is StringFieldValue other &&
                (this.MValue == null && other.MValue == null ||
                 this.MValue?.Equals(other.MValue) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"MValue = {this.MValue ?? "null"}");
        }
    }
}