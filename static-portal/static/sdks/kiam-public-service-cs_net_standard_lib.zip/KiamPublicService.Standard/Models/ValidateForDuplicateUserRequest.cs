// <copyright file="ValidateForDuplicateUserRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// ValidateForDuplicateUserRequest.
    /// </summary>
    public class ValidateForDuplicateUserRequest
    {
        private string firstname;
        private string lastname;
        private int? ssoId;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "firstname", false },
            { "lastname", false },
            { "ssoId", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateForDuplicateUserRequest"/> class.
        /// </summary>
        public ValidateForDuplicateUserRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateForDuplicateUserRequest"/> class.
        /// </summary>
        /// <param name="firstname">firstname.</param>
        /// <param name="lastname">lastname.</param>
        /// <param name="ssoId">ssoId.</param>
        /// <param name="mainAddress">mainAddress.</param>
        public ValidateForDuplicateUserRequest(
            string firstname = null,
            string lastname = null,
            int? ssoId = null,
            Models.AddressForDuplicateValidation mainAddress = null)
        {

            if (firstname != null)
            {
                this.Firstname = firstname;
            }

            if (lastname != null)
            {
                this.Lastname = lastname;
            }

            if (ssoId != null)
            {
                this.SsoId = ssoId;
            }
            this.MainAddress = mainAddress;
        }

        /// <summary>
        /// Gets or sets Firstname.
        /// </summary>
        [JsonProperty("firstname")]
        public string Firstname
        {
            get
            {
                return this.firstname;
            }

            set
            {
                this.shouldSerialize["firstname"] = true;
                this.firstname = value;
            }
        }

        /// <summary>
        /// Gets or sets Lastname.
        /// </summary>
        [JsonProperty("lastname")]
        public string Lastname
        {
            get
            {
                return this.lastname;
            }

            set
            {
                this.shouldSerialize["lastname"] = true;
                this.lastname = value;
            }
        }

        /// <summary>
        /// Gets or sets SsoId.
        /// </summary>
        [JsonProperty("ssoId")]
        public int? SsoId
        {
            get
            {
                return this.ssoId;
            }

            set
            {
                this.shouldSerialize["ssoId"] = true;
                this.ssoId = value;
            }
        }

        /// <summary>
        /// Gets or sets MainAddress.
        /// </summary>
        [JsonProperty("mainAddress", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddressForDuplicateValidation MainAddress { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ValidateForDuplicateUserRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetFirstname()
        {
            this.shouldSerialize["firstname"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetLastname()
        {
            this.shouldSerialize["lastname"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetSsoId()
        {
            this.shouldSerialize["ssoId"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeFirstname()
        {
            return this.shouldSerialize["firstname"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeLastname()
        {
            return this.shouldSerialize["lastname"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeSsoId()
        {
            return this.shouldSerialize["ssoId"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ValidateForDuplicateUserRequest other &&
                (this.Firstname == null && other.Firstname == null ||
                 this.Firstname?.Equals(other.Firstname) == true) &&
                (this.Lastname == null && other.Lastname == null ||
                 this.Lastname?.Equals(other.Lastname) == true) &&
                (this.SsoId == null && other.SsoId == null ||
                 this.SsoId?.Equals(other.SsoId) == true) &&
                (this.MainAddress == null && other.MainAddress == null ||
                 this.MainAddress?.Equals(other.MainAddress) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Firstname = {this.Firstname ?? "null"}");
            toStringOutput.Add($"Lastname = {this.Lastname ?? "null"}");
            toStringOutput.Add($"SsoId = {(this.SsoId == null ? "null" : this.SsoId.ToString())}");
            toStringOutput.Add($"MainAddress = {(this.MainAddress == null ? "null" : this.MainAddress.ToString())}");
        }
    }
}