// <copyright file="ConfirmRegistrationRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using KiamPublicService.Standard;
using KiamPublicService.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace KiamPublicService.Standard.Models
{
    /// <summary>
    /// ConfirmRegistrationRequest.
    /// </summary>
    public class ConfirmRegistrationRequest
    {
        private string token;
        private string applicationName;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "token", false },
            { "applicationName", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ConfirmRegistrationRequest"/> class.
        /// </summary>
        public ConfirmRegistrationRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConfirmRegistrationRequest"/> class.
        /// </summary>
        /// <param name="token">token.</param>
        /// <param name="applicationName">applicationName.</param>
        public ConfirmRegistrationRequest(
            string token = null,
            string applicationName = null)
        {

            if (token != null)
            {
                this.Token = token;
            }

            if (applicationName != null)
            {
                this.ApplicationName = applicationName;
            }
        }

        /// <summary>
        /// Gets or sets Token.
        /// </summary>
        [JsonProperty("token")]
        public string Token
        {
            get
            {
                return this.token;
            }

            set
            {
                this.shouldSerialize["token"] = true;
                this.token = value;
            }
        }

        /// <summary>
        /// Gets or sets ApplicationName.
        /// </summary>
        [JsonProperty("applicationName")]
        public string ApplicationName
        {
            get
            {
                return this.applicationName;
            }

            set
            {
                this.shouldSerialize["applicationName"] = true;
                this.applicationName = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ConfirmRegistrationRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetToken()
        {
            this.shouldSerialize["token"] = false;
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetApplicationName()
        {
            this.shouldSerialize["applicationName"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeToken()
        {
            return this.shouldSerialize["token"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeApplicationName()
        {
            return this.shouldSerialize["applicationName"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ConfirmRegistrationRequest other &&
                (this.Token == null && other.Token == null ||
                 this.Token?.Equals(other.Token) == true) &&
                (this.ApplicationName == null && other.ApplicationName == null ||
                 this.ApplicationName?.Equals(other.ApplicationName) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Token = {this.Token ?? "null"}");
            toStringOutput.Add($"ApplicationName = {this.ApplicationName ?? "null"}");
        }
    }
}