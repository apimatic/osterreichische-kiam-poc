
# Create Main Address Request

## Structure

`CreateMainAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryIsoAlpha2Code` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `Street` | `string` | Optional | - |
| `Street2` | `string` | Optional | - |
| `DoorNumber` | `string` | Optional | - |
| `HouseNumber` | `string` | Optional | - |
| `PostAddressCode` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code8",
  "postalCode": "postalCode6",
  "city": "city8",
  "street": "street2",
  "street2": "street22"
}
```

