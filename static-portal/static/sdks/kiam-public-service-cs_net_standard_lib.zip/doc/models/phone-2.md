
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryCode` | `string` | Optional | - |
| `AreaCode` | `string` | Optional | - |
| `Number` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

