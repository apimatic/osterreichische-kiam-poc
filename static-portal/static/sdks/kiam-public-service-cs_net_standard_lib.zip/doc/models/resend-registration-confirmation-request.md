
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Username` | `string` | Optional | - |
| `ApplicationName` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

