
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AddressType` | `int?` | Optional | - |
| `CountryIsoAlpha2Code` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `Street` | `string` | Optional | - |
| `Street2` | `string` | Optional | - |
| `DoorNumber` | `string` | Optional | - |
| `HouseNumber` | `string` | Optional | - |
| `PostAddressCode` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

