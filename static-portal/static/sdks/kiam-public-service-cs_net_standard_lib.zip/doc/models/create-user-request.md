
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Password` | `string` | Optional | - |
| `Username` | `string` | Optional | - |
| `Salutation` | `string` | Optional | - |
| `Firstname` | `string` | Optional | - |
| `Lastname` | `string` | Optional | - |
| `Birthdate` | `DateTime?` | Optional | - |
| `TitleBeforeName` | `string` | Optional | - |
| `TitleAfterName` | `string` | Optional | - |
| `Phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Addresses` | [`List<CreateAddressRequest>`](../../doc/models/create-address-request.md) | Optional | - |
| `RegistrationSucceededCallbackUrl` | `string` | Optional | - |
| `RegistrationOrigin` | `string` | Optional | - |
| `MarketingAgreement` | `bool?` | Optional | - |
| `Newsletter` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

