
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountryIsoAlpha2Code` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `Street` | `string` | Optional | - |
| `DoorNumber` | `string` | Optional | - |
| `HouseNumber` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

