
# Create Company Request

## Structure

`CreateCompanyRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `User` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Optional | - |
| `CompanyName` | `string` | Optional | - |
| `EmailAddress` | `string` | Optional | - |
| `Phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `Mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `MainAddress` | [`CreateMainAddressRequest`](../../doc/models/create-main-address-request.md) | Optional | - |
| `RegistrationSucceededCallbackUrl` | `string` | Optional | - |
| `Uid` | `string` | Optional | - |
| `LegalFormId` | `int?` | Optional | - |
| `OrganizationNumber` | `string` | Optional | - |
| `SapDebitor` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "user": {
    "password": "password4",
    "username": "username0",
    "salutation": "salutation4",
    "firstname": "firstname8",
    "lastname": "lastname6"
  },
  "companyName": "companyName6",
  "emailAddress": "emailAddress4",
  "phone": {
    "countryCode": "countryCode4",
    "areaCode": "areaCode2",
    "number": "number8"
  },
  "mobile": {
    "countryCode": "countryCode0",
    "areaCode": "areaCode6",
    "number": "number8"
  }
}
```

