
# Confirm Registration Request

## Structure

`ConfirmRegistrationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Token` | `string` | Optional | - |
| `ApplicationName` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "token": "token4",
  "applicationName": "applicationName6"
}
```

