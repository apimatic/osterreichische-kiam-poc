
# Validate for Duplicate User Request

## Structure

`ValidateForDuplicateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Firstname` | `string` | Optional | - |
| `Lastname` | `string` | Optional | - |
| `SsoId` | `int?` | Optional | - |
| `MainAddress` | [`AddressForDuplicateValidation`](../../doc/models/address-for-duplicate-validation.md) | Optional | - |

## Example (as JSON)

```json
{
  "firstname": "firstname0",
  "lastname": "lastname6",
  "ssoId": 190,
  "mainAddress": {
    "countryIsoAlpha2Code": "countryIsoAlpha2Code6",
    "postalCode": "postalCode4",
    "city": "city6",
    "street": "street4",
    "doorNumber": "doorNumber6"
  }
}
```

