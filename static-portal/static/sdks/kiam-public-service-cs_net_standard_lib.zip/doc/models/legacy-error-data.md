
# Legacy Error Data

## Structure

`LegacyErrorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | - |
| `MValue` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4"
}
```

