
# Kiam Problem Details Exception

*This model accepts additional fields of type object.*

## Structure

`KiamProblemDetailsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | - |
| `Title` | `string` | Optional | - |
| `Status` | `int?` | Optional | - |
| `Detail` | `string` | Optional | - |
| `Instance` | `string` | Optional | - |
| `Error` | [`LegacyErrorInfo`](../../doc/models/legacy-error-info.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "type8",
  "title": "title2",
  "status": 200,
  "detail": "detail8",
  "instance": "instance8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

