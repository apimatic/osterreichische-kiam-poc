# Public User

```csharp
PublicUserApi publicUserApi = client.PublicUserApi;
```

## Class Name

`PublicUserApi`


# Create User

```csharp
CreateUserAsync(
    string captchaToken = null,
    Models.CreateUserRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captchaToken` | `string` | Header, Optional | - |
| `body` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

`Task`

## Example Usage

```csharp
try
{
    await publicUserApi.CreateUserAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

