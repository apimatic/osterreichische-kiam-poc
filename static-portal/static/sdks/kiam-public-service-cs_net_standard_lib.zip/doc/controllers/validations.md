# Validations

```csharp
ValidationsApi validationsApi = client.ValidationsApi;
```

## Class Name

`ValidationsApi`

## Methods

* [Validate Username](../../doc/controllers/validations.md#validate-username)
* [Validate for Duplicate User](../../doc/controllers/validations.md#validate-for-duplicate-user)


# Validate Username

```csharp
ValidateUsernameAsync(
    Models.StringFieldValue body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`StringFieldValue`](../../doc/models/string-field-value.md) | Body, Optional | - |

## Response Type

`Task`

## Example Usage

```csharp
try
{
    await validationsApi.ValidateUsernameAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | - | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Validate for Duplicate User

```csharp
ValidateForDuplicateUserAsync(
    Models.ValidateForDuplicateUserRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidateForDuplicateUserRequest`](../../doc/models/validate-for-duplicate-user-request.md) | Body, Optional | - |

## Response Type

`Task`

## Example Usage

```csharp
try
{
    await validationsApi.ValidateForDuplicateUserAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Validation error code is duplicate_user | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |

