# Double Opt In

```csharp
DoubleOptInApi doubleOptInApi = client.DoubleOptInApi;
```

## Class Name

`DoubleOptInApi`

## Methods

* [Resend Registration Confirmation](../../doc/controllers/double-opt-in.md#resend-registration-confirmation)
* [Confirm Registration](../../doc/controllers/double-opt-in.md#confirm-registration)


# Resend Registration Confirmation

```csharp
ResendRegistrationConfirmationAsync(
    Models.ResendRegistrationConfirmationRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ResendRegistrationConfirmationRequest`](../../doc/models/resend-registration-confirmation-request.md) | Body, Optional | Request with username (email address) of the user. |

## Response Type

`Task`

## Example Usage

```csharp
try
{
    await doubleOptInApi.ResendRegistrationConfirmationAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | User with username was not found. | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |
| 409 | An error occurred | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Confirm Registration

```csharp
ConfirmRegistrationAsync(
    Models.ConfirmRegistrationRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConfirmRegistrationRequest`](../../doc/models/confirm-registration-request.md) | Body, Optional | - |

## Response Type

[`Task<ApiResponse<Models.RegistrationConfirmationResponse>>`](../../doc/models/registration-confirmation-response.md)

## Example Usage

```csharp
try
{
    ApiResponse<RegistrationConfirmationResponse> result = await doubleOptInApi.ConfirmRegistrationAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

