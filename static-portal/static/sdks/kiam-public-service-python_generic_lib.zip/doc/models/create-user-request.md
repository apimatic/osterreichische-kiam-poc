
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `password` | `str` | Optional | - |
| `username` | `str` | Optional | - |
| `salutation` | `str` | Optional | - |
| `firstname` | `str` | Optional | - |
| `lastname` | `str` | Optional | - |
| `birthdate` | `datetime` | Optional | - |
| `title_before_name` | `str` | Optional | - |
| `title_after_name` | `str` | Optional | - |
| `phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - |
| `addresses` | [`List[CreateAddressRequest]`](../../doc/models/create-address-request.md) | Optional | - |
| `registration_succeeded_callback_url` | `str` | Optional | - |
| `registration_origin` | `str` | Optional | - |
| `marketing_agreement` | `bool` | Optional | - |
| `newsletter` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

