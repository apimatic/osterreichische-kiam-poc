
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_type` | `int` | Optional | - |
| `country_iso_alpha_2_code` | `str` | Optional | - |
| `postal_code` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `street` | `str` | Optional | - |
| `street_2` | `str` | Optional | - |
| `door_number` | `str` | Optional | - |
| `house_number` | `str` | Optional | - |
| `post_address_code` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

