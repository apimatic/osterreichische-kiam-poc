
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `str` | Optional | - |
| `application_name` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

