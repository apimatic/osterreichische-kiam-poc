
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_iso_alpha_2_code` | `str` | Optional | - |
| `postal_code` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `street` | `str` | Optional | - |
| `door_number` | `str` | Optional | - |
| `house_number` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

