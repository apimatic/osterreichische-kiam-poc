
# Registration Confirmation Response

## Structure

`RegistrationConfirmationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callback_url` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "callbackUrl": "callbackUrl4"
}
```

