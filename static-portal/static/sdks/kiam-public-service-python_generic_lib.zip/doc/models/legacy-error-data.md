
# Legacy Error Data

## Structure

`LegacyErrorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `value` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4"
}
```

