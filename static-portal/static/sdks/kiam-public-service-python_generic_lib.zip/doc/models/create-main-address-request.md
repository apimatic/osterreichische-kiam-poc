
# Create Main Address Request

## Structure

`CreateMainAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_iso_alpha_2_code` | `str` | Optional | - |
| `postal_code` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `street` | `str` | Optional | - |
| `street_2` | `str` | Optional | - |
| `door_number` | `str` | Optional | - |
| `house_number` | `str` | Optional | - |
| `post_address_code` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code8",
  "postalCode": "postalCode6",
  "city": "city8",
  "street": "street2",
  "street2": "street22"
}
```

