
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_code` | `str` | Optional | - |
| `area_code` | `str` | Optional | - |
| `number` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

