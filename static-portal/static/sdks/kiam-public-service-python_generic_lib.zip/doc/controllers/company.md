# Company

```python
company_api = client.company
```

## Class Name

`CompanyApi`


# Create Company With Business User

```python
def create_company_with_business_user(self,
                                     captcha_token=None,
                                     body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captcha_token` | `str` | Header, Optional | This parameter is used to provide the captcha specific value for a token, solution or how else a parameter is called in a captcha solution. |
| `body` | [`CreateCompanyRequest`](../../doc/models/create-company-request.md) | Body, Optional | Data of the newly created company and related user.<br>User salutation can have values M or W, M means male and W means female, X means other.<br>Possible values for users' address type: 1 or 2. 1 means main address, 2 means secondary address.<br>If password is not defined or is null, created user will receive an e-mail and will have to set password using received link. |

## Response Type

This method returns a `ApiResponse` instance.

## Example Usage

```python
result = company_api.create_company_with_business_user()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request.<br><br>             Usual invalid request response format:<br>             Error code is validation_error. Information about the error can be found in the details field.<br>             Target describes which field is invalid, validation error code defines the more detailed validation error case.<br>             There could be multiple errors per field. See example response.<br>            <br>             List of error codes in format [error code] - [optional description] - [fields which can have this validation error] for user fields and company fields:<br>            <br>             Company fields<br>            <br>             required - company_name<br>             invalid - company_legal_form_id, company_email_address, company_phone_country_code, company_phone_area_code, company_phone_number, company_mobile_country_code, company_mobile_area_code, company_mobile_number, company_countryIsoAlpha2Code<br>            <br>             User fields<br>             <br>             required -  Required field. - username, first_name, last_name, registration_origin<br>             username_not_available - Username is already taken. - username<br>             too_short - The input value is too short. - username, first_name, last_name<br>             too_long - The input value is too long. - username, first_name, last_name<br>             no_titles_allowed - No titles allowed, E.g. BSc. - first_name, last_name<br>             no_company_types_allowed - No company types allowed. E.g. GmbH. - first_name, last_name<br>             person_too_young - Person with specified birthdate is too young. - birthdate<br>             invalid - first_name, last_name, username, phone_country_code, phone_area_code, phone_number, mobile_country_code, mobile_area_code, mobile_number, user_addressX_countryIsoAlpha2Code (where X is the index of the address in the array, starting from 0, e.G. user_address0_countryIsoAlpha2Code)<br>             new_password_invalid - the new password is invalid - password<br>             captcha_error - Invalid Captcha token. | `ApiException` |

