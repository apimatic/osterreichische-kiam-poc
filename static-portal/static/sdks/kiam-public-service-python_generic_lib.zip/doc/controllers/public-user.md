# Public User

```python
public_user_api = client.public_user
```

## Class Name

`PublicUserApi`


# Create User

```python
def create_user(self,
               captcha_token=None,
               body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captcha_token` | `str` | Header, Optional | - |
| `body` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

This method returns a `ApiResponse` instance.

## Example Usage

```python
result = public_user_api.create_user()
```

