
# Registration Confirmation Response

## Structure

`RegistrationConfirmationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callbackUrl` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "callbackUrl": "callbackUrl4"
}
```

