
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `password` | `string \| null \| undefined` | Optional | - |
| `username` | `string \| null \| undefined` | Optional | - |
| `salutation` | `string \| null \| undefined` | Optional | - |
| `firstname` | `string \| null \| undefined` | Optional | - |
| `lastname` | `string \| null \| undefined` | Optional | - |
| `birthdate` | `string \| null \| undefined` | Optional | - |
| `titleBeforeName` | `string \| null \| undefined` | Optional | - |
| `titleAfterName` | `string \| null \| undefined` | Optional | - |
| `phone` | [`Phone2 \| undefined`](../../doc/models/phone-2.md) | Optional | - |
| `mobile` | [`Phone2 \| undefined`](../../doc/models/phone-2.md) | Optional | - |
| `addresses` | [`CreateAddressRequest[] \| null \| undefined`](../../doc/models/create-address-request.md) | Optional | - |
| `registrationSucceededCallbackUrl` | `string \| null \| undefined` | Optional | - |
| `registrationOrigin` | `string \| null \| undefined` | Optional | - |
| `marketingAgreement` | `boolean \| null \| undefined` | Optional | - |
| `newsletter` | `boolean \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

