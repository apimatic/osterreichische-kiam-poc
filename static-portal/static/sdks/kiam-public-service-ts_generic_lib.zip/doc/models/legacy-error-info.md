
# Legacy Error Info

## Structure

`LegacyErrorInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string \| null \| undefined` | Optional | - |
| `message` | `string \| null \| undefined` | Optional | - |
| `target` | `string \| null \| undefined` | Optional | - |
| `data` | [`LegacyErrorData[] \| null \| undefined`](../../doc/models/legacy-error-data.md) | Optional | - |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0",
  "target": "target8",
  "data": [
    {
      "name": "name0",
      "value": "value2"
    }
  ]
}
```

