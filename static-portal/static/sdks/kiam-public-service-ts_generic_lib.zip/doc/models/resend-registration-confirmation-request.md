
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string \| null \| undefined` | Optional | - |
| `applicationName` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

