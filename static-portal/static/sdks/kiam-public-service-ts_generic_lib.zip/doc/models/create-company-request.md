
# Create Company Request

## Structure

`CreateCompanyRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user` | [`CreateUserRequest \| undefined`](../../doc/models/create-user-request.md) | Optional | - |
| `companyName` | `string \| null \| undefined` | Optional | - |
| `emailAddress` | `string \| null \| undefined` | Optional | - |
| `phone` | [`Phone2 \| undefined`](../../doc/models/phone-2.md) | Optional | - |
| `mobile` | [`Phone2 \| undefined`](../../doc/models/phone-2.md) | Optional | - |
| `mainAddress` | [`CreateMainAddressRequest \| undefined`](../../doc/models/create-main-address-request.md) | Optional | - |
| `registrationSucceededCallbackUrl` | `string \| null \| undefined` | Optional | - |
| `uid` | `string \| null \| undefined` | Optional | - |
| `legalFormId` | `number \| null \| undefined` | Optional | - |
| `organizationNumber` | `string \| null \| undefined` | Optional | - |
| `sapDebitor` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "user": {
    "password": "password4",
    "username": "username0",
    "salutation": "salutation4",
    "firstname": "firstname8",
    "lastname": "lastname6"
  },
  "companyName": "companyName6",
  "emailAddress": "emailAddress4",
  "phone": {
    "countryCode": "countryCode4",
    "areaCode": "areaCode2",
    "number": "number8"
  },
  "mobile": {
    "countryCode": "countryCode0",
    "areaCode": "areaCode6",
    "number": "number8"
  }
}
```

