
# String Field Value

## Structure

`StringFieldValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `value` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "value": "value2"
}
```

