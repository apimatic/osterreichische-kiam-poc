
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countryCode` | `string \| null \| undefined` | Optional | - |
| `areaCode` | `string \| null \| undefined` | Optional | - |
| `number` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

