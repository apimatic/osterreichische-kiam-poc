
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `addressType` | `number \| null \| undefined` | Optional | - |
| `countryIsoAlpha2Code` | `string \| null \| undefined` | Optional | - |
| `postalCode` | `string \| null \| undefined` | Optional | - |
| `city` | `string \| null \| undefined` | Optional | - |
| `street` | `string \| null \| undefined` | Optional | - |
| `street2` | `string \| null \| undefined` | Optional | - |
| `doorNumber` | `string \| null \| undefined` | Optional | - |
| `houseNumber` | `string \| null \| undefined` | Optional | - |
| `postAddressCode` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

