
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countryIsoAlpha2Code` | `string \| null \| undefined` | Optional | - |
| `postalCode` | `string \| null \| undefined` | Optional | - |
| `city` | `string \| null \| undefined` | Optional | - |
| `street` | `string \| null \| undefined` | Optional | - |
| `doorNumber` | `string \| null \| undefined` | Optional | - |
| `houseNumber` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

