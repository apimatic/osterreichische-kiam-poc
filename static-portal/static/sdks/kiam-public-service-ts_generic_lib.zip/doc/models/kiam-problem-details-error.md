
# Kiam Problem Details Error

*This model accepts additional fields of type unknown.*

## Structure

`KiamProblemDetailsError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| null \| undefined` | Optional | - |
| `title` | `string \| null \| undefined` | Optional | - |
| `status` | `number \| null \| undefined` | Optional | - |
| `detail` | `string \| null \| undefined` | Optional | - |
| `instance` | `string \| null \| undefined` | Optional | - |
| `error` | [`LegacyErrorInfo \| undefined`](../../doc/models/legacy-error-info.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "type": "type8",
  "title": "title2",
  "status": 200,
  "detail": "detail8",
  "instance": "instance8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

