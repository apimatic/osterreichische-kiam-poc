
# Create Main Address Request

## Structure

`CreateMainAddressRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countryIsoAlpha2Code` | `string \| null \| undefined` | Optional | - |
| `postalCode` | `string \| null \| undefined` | Optional | - |
| `city` | `string \| null \| undefined` | Optional | - |
| `street` | `string \| null \| undefined` | Optional | - |
| `street2` | `string \| null \| undefined` | Optional | - |
| `doorNumber` | `string \| null \| undefined` | Optional | - |
| `houseNumber` | `string \| null \| undefined` | Optional | - |
| `postAddressCode` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code8",
  "postalCode": "postalCode6",
  "city": "city8",
  "street": "street2",
  "street2": "street22"
}
```

