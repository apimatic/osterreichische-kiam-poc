
# Legacy Error Data

## Structure

`LegacyErrorData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| null \| undefined` | Optional | - |
| `value` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name2",
  "value": "value4"
}
```

