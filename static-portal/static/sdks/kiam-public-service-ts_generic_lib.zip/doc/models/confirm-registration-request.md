
# Confirm Registration Request

## Structure

`ConfirmRegistrationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| null \| undefined` | Optional | - |
| `applicationName` | `string \| null \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "token": "token4",
  "applicationName": "applicationName6"
}
```

