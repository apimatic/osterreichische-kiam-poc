# Double Opt In

```ts
const doubleOptInApi = new DoubleOptInApi(client);
```

## Class Name

`DoubleOptInApi`

## Methods

* [Resend Registration Confirmation](../../doc/controllers/double-opt-in.md#resend-registration-confirmation)
* [Confirm Registration](../../doc/controllers/double-opt-in.md#confirm-registration)


# Resend Registration Confirmation

```ts
async resendRegistrationConfirmation(
  body?: ResendRegistrationConfirmationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ResendRegistrationConfirmationRequest \| undefined`](../../doc/models/resend-registration-confirmation-request.md) | Body, Optional | Request with username (email address) of the user. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await doubleOptInApi.resendRegistrationConfirmation();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | User with username was not found. | [`KiamProblemDetailsError`](../../doc/models/kiam-problem-details-error.md) |
| 409 | An error occurred | [`KiamProblemDetailsError`](../../doc/models/kiam-problem-details-error.md) |


# Confirm Registration

```ts
async confirmRegistration(
  body?: ConfirmRegistrationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<RegistrationConfirmationResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConfirmRegistrationRequest \| undefined`](../../doc/models/confirm-registration-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`RegistrationConfirmationResponse`](../../doc/models/registration-confirmation-response.md)

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await doubleOptInApi.confirmRegistration();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

