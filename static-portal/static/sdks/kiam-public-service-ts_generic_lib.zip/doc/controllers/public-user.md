# Public User

```ts
const publicUserApi = new PublicUserApi(client);
```

## Class Name

`PublicUserApi`


# Create User

```ts
async createUser(
  captchaToken?: string,
  body?: CreateUserRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captchaToken` | `string \| undefined` | Header, Optional | - |
| `body` | [`CreateUserRequest \| undefined`](../../doc/models/create-user-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await publicUserApi.createUser();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

