# Validations

```ts
const validationsApi = new ValidationsApi(client);
```

## Class Name

`ValidationsApi`

## Methods

* [Validate Username](../../doc/controllers/validations.md#validate-username)
* [Validate for Duplicate User](../../doc/controllers/validations.md#validate-for-duplicate-user)


# Validate Username

```ts
async validateUsername(
  body?: StringFieldValue,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`StringFieldValue \| undefined`](../../doc/models/string-field-value.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await validationsApi.validateUsername();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | - | [`KiamProblemDetailsError`](../../doc/models/kiam-problem-details-error.md) |


# Validate for Duplicate User

```ts
async validateForDuplicateUser(
  body?: ValidateForDuplicateUserRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidateForDuplicateUserRequest \| undefined`](../../doc/models/validate-for-duplicate-user-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await validationsApi.validateForDuplicateUser();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Validation error code is duplicate_user | [`KiamProblemDetailsError`](../../doc/models/kiam-problem-details-error.md) |

