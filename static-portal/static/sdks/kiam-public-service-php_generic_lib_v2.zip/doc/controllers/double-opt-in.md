# Double Opt In

```php
$doubleOptInApi = $client->getDoubleOptInApi();
```

## Class Name

`DoubleOptInApi`

## Methods

* [Resend Registration Confirmation](../../doc/controllers/double-opt-in.md#resend-registration-confirmation)
* [Confirm Registration](../../doc/controllers/double-opt-in.md#confirm-registration)


# Resend Registration Confirmation

```php
function resendRegistrationConfirmation(?ResendRegistrationConfirmationRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?ResendRegistrationConfirmationRequest`](../../doc/models/resend-registration-confirmation-request.md) | Body, Optional | Request with username (email address) of the user. |

## Response Type

This method returns a `KiamPublicServiceLib\Utils\ApiResponse` instance.

## Example Usage

```php
$apiResponse = $doubleOptInApi->resendRegistrationConfirmation();
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | User with username was not found. | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |
| 409 | An error occurred | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Confirm Registration

```php
function confirmRegistration(?ConfirmRegistrationRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?ConfirmRegistrationRequest`](../../doc/models/confirm-registration-request.md) | Body, Optional | - |

## Response Type

This method returns a `KiamPublicServiceLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type [`RegistrationConfirmationResponse`](../../doc/models/registration-confirmation-response.md).

## Example Usage

```php
$apiResponse = $doubleOptInApi->confirmRegistration();
```

