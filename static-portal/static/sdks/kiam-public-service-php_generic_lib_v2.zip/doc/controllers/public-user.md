# Public User

```php
$publicUserApi = $client->getPublicUserApi();
```

## Class Name

`PublicUserApi`


# Create User

```php
function createUser(?string $captchaToken = null, ?CreateUserRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captchaToken` | `?string` | Header, Optional | - |
| `body` | [`?CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

This method returns a `KiamPublicServiceLib\Utils\ApiResponse` instance.

## Example Usage

```php
$apiResponse = $publicUserApi->createUser();
```

