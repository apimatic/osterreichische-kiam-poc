
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `password` | `?string` | Optional | - | getPassword(): ?string | setPassword(?string password): void |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `salutation` | `?string` | Optional | - | getSalutation(): ?string | setSalutation(?string salutation): void |
| `firstname` | `?string` | Optional | - | getFirstname(): ?string | setFirstname(?string firstname): void |
| `lastname` | `?string` | Optional | - | getLastname(): ?string | setLastname(?string lastname): void |
| `birthdate` | `?DateTime` | Optional | - | getBirthdate(): ?\DateTime | setBirthdate(?\DateTime birthdate): void |
| `titleBeforeName` | `?string` | Optional | - | getTitleBeforeName(): ?string | setTitleBeforeName(?string titleBeforeName): void |
| `titleAfterName` | `?string` | Optional | - | getTitleAfterName(): ?string | setTitleAfterName(?string titleAfterName): void |
| `phone` | [`?Phone2`](../../doc/models/phone-2.md) | Optional | - | getPhone(): ?Phone2 | setPhone(?Phone2 phone): void |
| `mobile` | [`?Phone2`](../../doc/models/phone-2.md) | Optional | - | getMobile(): ?Phone2 | setMobile(?Phone2 mobile): void |
| `addresses` | [`?(CreateAddressRequest[])`](../../doc/models/create-address-request.md) | Optional | - | getAddresses(): ?array | setAddresses(?array addresses): void |
| `registrationSucceededCallbackUrl` | `?string` | Optional | - | getRegistrationSucceededCallbackUrl(): ?string | setRegistrationSucceededCallbackUrl(?string registrationSucceededCallbackUrl): void |
| `registrationOrigin` | `?string` | Optional | - | getRegistrationOrigin(): ?string | setRegistrationOrigin(?string registrationOrigin): void |
| `marketingAgreement` | `?bool` | Optional | - | getMarketingAgreement(): ?bool | setMarketingAgreement(?bool marketingAgreement): void |
| `newsletter` | `?bool` | Optional | - | getNewsletter(): ?bool | setNewsletter(?bool newsletter): void |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

