
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `applicationName` | `?string` | Optional | - | getApplicationName(): ?string | setApplicationName(?string applicationName): void |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

