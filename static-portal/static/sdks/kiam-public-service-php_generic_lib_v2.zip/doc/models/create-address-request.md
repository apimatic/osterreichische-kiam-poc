
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `addressType` | `?int` | Optional | - | getAddressType(): ?int | setAddressType(?int addressType): void |
| `countryIsoAlpha2Code` | `?string` | Optional | - | getCountryIsoAlpha2Code(): ?string | setCountryIsoAlpha2Code(?string countryIsoAlpha2Code): void |
| `postalCode` | `?string` | Optional | - | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `city` | `?string` | Optional | - | getCity(): ?string | setCity(?string city): void |
| `street` | `?string` | Optional | - | getStreet(): ?string | setStreet(?string street): void |
| `street2` | `?string` | Optional | - | getStreet2(): ?string | setStreet2(?string street2): void |
| `doorNumber` | `?string` | Optional | - | getDoorNumber(): ?string | setDoorNumber(?string doorNumber): void |
| `houseNumber` | `?string` | Optional | - | getHouseNumber(): ?string | setHouseNumber(?string houseNumber): void |
| `postAddressCode` | `?string` | Optional | - | getPostAddressCode(): ?string | setPostAddressCode(?string postAddressCode): void |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

