
# Create Company Request

## Structure

`CreateCompanyRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `user` | [`?CreateUserRequest`](../../doc/models/create-user-request.md) | Optional | - | getUser(): ?CreateUserRequest | setUser(?CreateUserRequest user): void |
| `companyName` | `?string` | Optional | - | getCompanyName(): ?string | setCompanyName(?string companyName): void |
| `emailAddress` | `?string` | Optional | - | getEmailAddress(): ?string | setEmailAddress(?string emailAddress): void |
| `phone` | [`?Phone2`](../../doc/models/phone-2.md) | Optional | - | getPhone(): ?Phone2 | setPhone(?Phone2 phone): void |
| `mobile` | [`?Phone2`](../../doc/models/phone-2.md) | Optional | - | getMobile(): ?Phone2 | setMobile(?Phone2 mobile): void |
| `mainAddress` | [`?CreateMainAddressRequest`](../../doc/models/create-main-address-request.md) | Optional | - | getMainAddress(): ?CreateMainAddressRequest | setMainAddress(?CreateMainAddressRequest mainAddress): void |
| `registrationSucceededCallbackUrl` | `?string` | Optional | - | getRegistrationSucceededCallbackUrl(): ?string | setRegistrationSucceededCallbackUrl(?string registrationSucceededCallbackUrl): void |
| `uid` | `?string` | Optional | - | getUid(): ?string | setUid(?string uid): void |
| `legalFormId` | `?int` | Optional | - | getLegalFormId(): ?int | setLegalFormId(?int legalFormId): void |
| `organizationNumber` | `?string` | Optional | - | getOrganizationNumber(): ?string | setOrganizationNumber(?string organizationNumber): void |
| `sapDebitor` | `?string` | Optional | - | getSapDebitor(): ?string | setSapDebitor(?string sapDebitor): void |

## Example (as JSON)

```json
{
  "user": {
    "password": "password4",
    "username": "username0",
    "salutation": "salutation4",
    "firstname": "firstname8",
    "lastname": "lastname6"
  },
  "companyName": "companyName6",
  "emailAddress": "emailAddress4",
  "phone": {
    "countryCode": "countryCode4",
    "areaCode": "areaCode2",
    "number": "number8"
  },
  "mobile": {
    "countryCode": "countryCode0",
    "areaCode": "areaCode6",
    "number": "number8"
  }
}
```

