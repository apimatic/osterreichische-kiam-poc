
# Kiam Problem Details Exception

*This model accepts additional fields of type array.*

## Structure

`KiamProblemDetailsException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `status` | `?int` | Optional | - | getStatus(): ?int | setStatus(?int status): void |
| `detail` | `?string` | Optional | - | getDetail(): ?string | setDetail(?string detail): void |
| `instance` | `?string` | Optional | - | getInstance(): ?string | setInstance(?string instance): void |
| `error` | [`?LegacyErrorInfo`](../../doc/models/legacy-error-info.md) | Optional | - | getError(): ?LegacyErrorInfo | setError(?LegacyErrorInfo error): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "type": "type8",
  "title": "title2",
  "status": 200,
  "detail": "detail8",
  "instance": "instance8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

