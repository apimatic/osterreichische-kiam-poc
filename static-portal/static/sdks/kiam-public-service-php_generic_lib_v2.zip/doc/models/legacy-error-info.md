
# Legacy Error Info

## Structure

`LegacyErrorInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `?string` | Optional | - | getCode(): ?string | setCode(?string code): void |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |
| `target` | `?string` | Optional | - | getTarget(): ?string | setTarget(?string target): void |
| `data` | [`?(LegacyErrorData[])`](../../doc/models/legacy-error-data.md) | Optional | - | getData(): ?array | setData(?array data): void |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0",
  "target": "target8",
  "data": [
    {
      "name": "name0",
      "value": "value2"
    }
  ]
}
```

