
# Confirm Registration Request

## Structure

`ConfirmRegistrationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | - | getToken(): ?string | setToken(?string token): void |
| `applicationName` | `?string` | Optional | - | getApplicationName(): ?string | setApplicationName(?string applicationName): void |

## Example (as JSON)

```json
{
  "token": "token4",
  "applicationName": "applicationName6"
}
```

