
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `countryIsoAlpha2Code` | `?string` | Optional | - | getCountryIsoAlpha2Code(): ?string | setCountryIsoAlpha2Code(?string countryIsoAlpha2Code): void |
| `postalCode` | `?string` | Optional | - | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `city` | `?string` | Optional | - | getCity(): ?string | setCity(?string city): void |
| `street` | `?string` | Optional | - | getStreet(): ?string | setStreet(?string street): void |
| `doorNumber` | `?string` | Optional | - | getDoorNumber(): ?string | setDoorNumber(?string doorNumber): void |
| `houseNumber` | `?string` | Optional | - | getHouseNumber(): ?string | setHouseNumber(?string houseNumber): void |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

