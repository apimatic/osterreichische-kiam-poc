
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `countryCode` | `?string` | Optional | - | getCountryCode(): ?string | setCountryCode(?string countryCode): void |
| `areaCode` | `?string` | Optional | - | getAreaCode(): ?string | setAreaCode(?string areaCode): void |
| `number` | `?string` | Optional | - | getNumber(): ?string | setNumber(?string number): void |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

