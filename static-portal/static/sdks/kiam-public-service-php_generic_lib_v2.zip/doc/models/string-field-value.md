
# String Field Value

## Structure

`StringFieldValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |

## Example (as JSON)

```json
{
  "value": "value2"
}
```

