
# Validate for Duplicate User Request

## Structure

`ValidateForDuplicateUserRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstname` | `?string` | Optional | - | getFirstname(): ?string | setFirstname(?string firstname): void |
| `lastname` | `?string` | Optional | - | getLastname(): ?string | setLastname(?string lastname): void |
| `ssoId` | `?int` | Optional | - | getSsoId(): ?int | setSsoId(?int ssoId): void |
| `mainAddress` | [`?AddressForDuplicateValidation`](../../doc/models/address-for-duplicate-validation.md) | Optional | - | getMainAddress(): ?AddressForDuplicateValidation | setMainAddress(?AddressForDuplicateValidation mainAddress): void |

## Example (as JSON)

```json
{
  "firstname": "firstname0",
  "lastname": "lastname6",
  "ssoId": 190,
  "mainAddress": {
    "countryIsoAlpha2Code": "countryIsoAlpha2Code6",
    "postalCode": "postalCode4",
    "city": "city6",
    "street": "street4",
    "doorNumber": "doorNumber6"
  }
}
```

