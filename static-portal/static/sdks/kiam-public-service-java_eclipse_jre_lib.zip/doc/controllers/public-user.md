# Public User

```java
PublicUserApi publicUserApi = client.getPublicUserApi();
```

## Class Name

`PublicUserApi`


# Create User

```java
CompletableFuture<ApiResponse<Void>> createUserAsync(
    final String captchaToken,
    final CreateUserRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `captchaToken` | `String` | Header, Optional | - |
| `body` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Body, Optional | - |

## Response Type

`void`

## Example Usage

```java
publicUserApi.createUserAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

