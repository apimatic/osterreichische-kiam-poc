# Validations

```java
ValidationsApi validationsApi = client.getValidationsApi();
```

## Class Name

`ValidationsApi`

## Methods

* [Validate Username](../../doc/controllers/validations.md#validate-username)
* [Validate for Duplicate User](../../doc/controllers/validations.md#validate-for-duplicate-user)


# Validate Username

```java
CompletableFuture<ApiResponse<Void>> validateUsernameAsync(
    final StringFieldValue body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`StringFieldValue`](../../doc/models/string-field-value.md) | Body, Optional | - |

## Response Type

`void`

## Example Usage

```java
validationsApi.validateUsernameAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | - | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Validate for Duplicate User

```java
CompletableFuture<ApiResponse<Void>> validateForDuplicateUserAsync(
    final ValidateForDuplicateUserRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ValidateForDuplicateUserRequest`](../../doc/models/validate-for-duplicate-user-request.md) | Body, Optional | - |

## Response Type

`void`

## Example Usage

```java
validationsApi.validateForDuplicateUserAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Validation error code is duplicate_user | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |

