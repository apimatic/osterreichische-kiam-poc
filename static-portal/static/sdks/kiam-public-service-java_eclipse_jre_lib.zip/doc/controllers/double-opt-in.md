# Double Opt In

```java
DoubleOptInApi doubleOptInApi = client.getDoubleOptInApi();
```

## Class Name

`DoubleOptInApi`

## Methods

* [Resend Registration Confirmation](../../doc/controllers/double-opt-in.md#resend-registration-confirmation)
* [Confirm Registration](../../doc/controllers/double-opt-in.md#confirm-registration)


# Resend Registration Confirmation

```java
CompletableFuture<ApiResponse<Void>> resendRegistrationConfirmationAsync(
    final ResendRegistrationConfirmationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ResendRegistrationConfirmationRequest`](../../doc/models/resend-registration-confirmation-request.md) | Body, Optional | Request with username (email address) of the user. |

## Response Type

`void`

## Example Usage

```java
doubleOptInApi.resendRegistrationConfirmationAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | User with username was not found. | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |
| 409 | An error occurred | [`KiamProblemDetailsException`](../../doc/models/kiam-problem-details-exception.md) |


# Confirm Registration

```java
CompletableFuture<ApiResponse<RegistrationConfirmationResponse>> confirmRegistrationAsync(
    final ConfirmRegistrationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConfirmRegistrationRequest`](../../doc/models/confirm-registration-request.md) | Body, Optional | - |

## Response Type

[`RegistrationConfirmationResponse`](../../doc/models/registration-confirmation-response.md)

## Example Usage

```java
doubleOptInApi.confirmRegistrationAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

