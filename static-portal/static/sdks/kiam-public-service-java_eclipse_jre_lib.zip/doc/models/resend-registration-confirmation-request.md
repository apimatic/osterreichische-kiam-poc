
# Resend Registration Confirmation Request

## Structure

`ResendRegistrationConfirmationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Username` | `String` | Optional | - | String getUsername() | setUsername(String username) |
| `ApplicationName` | `String` | Optional | - | String getApplicationName() | setApplicationName(String applicationName) |

## Example (as JSON)

```json
{
  "username": "username0",
  "applicationName": "applicationName8"
}
```

