
# Kiam Problem Details Exception

*This model accepts additional fields of type Object.*

## Structure

`KiamProblemDetailsException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `String` | Optional | - | String getType() | setType(String type) |
| `Title` | `String` | Optional | - | String getTitle() | setTitle(String title) |
| `Status` | `Integer` | Optional | - | Integer getStatus() | setStatus(Integer status) |
| `Detail` | `String` | Optional | - | String getDetail() | setDetail(String detail) |
| `Instance` | `String` | Optional | - | String getInstance() | setInstance(String instance) |
| `Error` | [`LegacyErrorInfo`](../../doc/models/legacy-error-info.md) | Optional | - | LegacyErrorInfo getError() | setError(LegacyErrorInfo error) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "type8",
  "title": "title2",
  "status": 200,
  "detail": "detail8",
  "instance": "instance8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

