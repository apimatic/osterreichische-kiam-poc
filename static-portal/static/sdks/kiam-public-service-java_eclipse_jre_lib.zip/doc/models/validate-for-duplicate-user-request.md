
# Validate for Duplicate User Request

## Structure

`ValidateForDuplicateUserRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Firstname` | `String` | Optional | - | String getFirstname() | setFirstname(String firstname) |
| `Lastname` | `String` | Optional | - | String getLastname() | setLastname(String lastname) |
| `SsoId` | `Integer` | Optional | - | Integer getSsoId() | setSsoId(Integer ssoId) |
| `MainAddress` | [`AddressForDuplicateValidation`](../../doc/models/address-for-duplicate-validation.md) | Optional | - | AddressForDuplicateValidation getMainAddress() | setMainAddress(AddressForDuplicateValidation mainAddress) |

## Example (as JSON)

```json
{
  "firstname": "firstname0",
  "lastname": "lastname6",
  "ssoId": 190,
  "mainAddress": {
    "countryIsoAlpha2Code": "countryIsoAlpha2Code6",
    "postalCode": "postalCode4",
    "city": "city6",
    "street": "street4",
    "doorNumber": "doorNumber6"
  }
}
```

