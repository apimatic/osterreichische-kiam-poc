
# Address for Duplicate Validation

## Structure

`AddressForDuplicateValidation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountryIsoAlpha2Code` | `String` | Optional | - | String getCountryIsoAlpha2Code() | setCountryIsoAlpha2Code(String countryIsoAlpha2Code) |
| `PostalCode` | `String` | Optional | - | String getPostalCode() | setPostalCode(String postalCode) |
| `City` | `String` | Optional | - | String getCity() | setCity(String city) |
| `Street` | `String` | Optional | - | String getStreet() | setStreet(String street) |
| `DoorNumber` | `String` | Optional | - | String getDoorNumber() | setDoorNumber(String doorNumber) |
| `HouseNumber` | `String` | Optional | - | String getHouseNumber() | setHouseNumber(String houseNumber) |

## Example (as JSON)

```json
{
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode6",
  "city": "city4",
  "street": "street4",
  "doorNumber": "doorNumber6"
}
```

