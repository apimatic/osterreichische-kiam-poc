
# Create Company Request

## Structure

`CreateCompanyRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `User` | [`CreateUserRequest`](../../doc/models/create-user-request.md) | Optional | - | CreateUserRequest getUser() | setUser(CreateUserRequest user) |
| `CompanyName` | `String` | Optional | - | String getCompanyName() | setCompanyName(String companyName) |
| `EmailAddress` | `String` | Optional | - | String getEmailAddress() | setEmailAddress(String emailAddress) |
| `Phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - | Phone2 getPhone() | setPhone(Phone2 phone) |
| `Mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - | Phone2 getMobile() | setMobile(Phone2 mobile) |
| `MainAddress` | [`CreateMainAddressRequest`](../../doc/models/create-main-address-request.md) | Optional | - | CreateMainAddressRequest getMainAddress() | setMainAddress(CreateMainAddressRequest mainAddress) |
| `RegistrationSucceededCallbackUrl` | `String` | Optional | - | String getRegistrationSucceededCallbackUrl() | setRegistrationSucceededCallbackUrl(String registrationSucceededCallbackUrl) |
| `Uid` | `String` | Optional | - | String getUid() | setUid(String uid) |
| `LegalFormId` | `Integer` | Optional | - | Integer getLegalFormId() | setLegalFormId(Integer legalFormId) |
| `OrganizationNumber` | `String` | Optional | - | String getOrganizationNumber() | setOrganizationNumber(String organizationNumber) |
| `SapDebitor` | `String` | Optional | - | String getSapDebitor() | setSapDebitor(String sapDebitor) |

## Example (as JSON)

```json
{
  "user": {
    "password": "password4",
    "username": "username0",
    "salutation": "salutation4",
    "firstname": "firstname8",
    "lastname": "lastname6"
  },
  "companyName": "companyName6",
  "emailAddress": "emailAddress4",
  "phone": {
    "countryCode": "countryCode4",
    "areaCode": "areaCode2",
    "number": "number8"
  },
  "mobile": {
    "countryCode": "countryCode0",
    "areaCode": "areaCode6",
    "number": "number8"
  }
}
```

