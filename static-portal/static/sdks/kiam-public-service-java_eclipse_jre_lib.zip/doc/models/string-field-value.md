
# String Field Value

## Structure

`StringFieldValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Value` | `String` | Optional | - | String getValue() | setValue(String value) |

## Example (as JSON)

```json
{
  "value": "value2"
}
```

