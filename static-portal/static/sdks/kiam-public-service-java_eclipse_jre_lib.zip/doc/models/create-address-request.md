
# Create Address Request

## Structure

`CreateAddressRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AddressType` | `Integer` | Optional | - | Integer getAddressType() | setAddressType(Integer addressType) |
| `CountryIsoAlpha2Code` | `String` | Optional | - | String getCountryIsoAlpha2Code() | setCountryIsoAlpha2Code(String countryIsoAlpha2Code) |
| `PostalCode` | `String` | Optional | - | String getPostalCode() | setPostalCode(String postalCode) |
| `City` | `String` | Optional | - | String getCity() | setCity(String city) |
| `Street` | `String` | Optional | - | String getStreet() | setStreet(String street) |
| `Street2` | `String` | Optional | - | String getStreet2() | setStreet2(String street2) |
| `DoorNumber` | `String` | Optional | - | String getDoorNumber() | setDoorNumber(String doorNumber) |
| `HouseNumber` | `String` | Optional | - | String getHouseNumber() | setHouseNumber(String houseNumber) |
| `PostAddressCode` | `String` | Optional | - | String getPostAddressCode() | setPostAddressCode(String postAddressCode) |

## Example (as JSON)

```json
{
  "addressType": 38,
  "countryIsoAlpha2Code": "countryIsoAlpha2Code4",
  "postalCode": "postalCode2",
  "city": "city6",
  "street": "street6"
}
```

