
# Registration Confirmation Response

## Structure

`RegistrationConfirmationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CallbackUrl` | `String` | Optional | - | String getCallbackUrl() | setCallbackUrl(String callbackUrl) |

## Example (as JSON)

```json
{
  "callbackUrl": "callbackUrl4"
}
```

