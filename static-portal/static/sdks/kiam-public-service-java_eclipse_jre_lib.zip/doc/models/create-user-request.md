
# Create User Request

## Structure

`CreateUserRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Password` | `String` | Optional | - | String getPassword() | setPassword(String password) |
| `Username` | `String` | Optional | - | String getUsername() | setUsername(String username) |
| `Salutation` | `String` | Optional | - | String getSalutation() | setSalutation(String salutation) |
| `Firstname` | `String` | Optional | - | String getFirstname() | setFirstname(String firstname) |
| `Lastname` | `String` | Optional | - | String getLastname() | setLastname(String lastname) |
| `Birthdate` | `LocalDateTime` | Optional | - | LocalDateTime getBirthdate() | setBirthdate(LocalDateTime birthdate) |
| `TitleBeforeName` | `String` | Optional | - | String getTitleBeforeName() | setTitleBeforeName(String titleBeforeName) |
| `TitleAfterName` | `String` | Optional | - | String getTitleAfterName() | setTitleAfterName(String titleAfterName) |
| `Phone` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - | Phone2 getPhone() | setPhone(Phone2 phone) |
| `Mobile` | [`Phone2`](../../doc/models/phone-2.md) | Optional | - | Phone2 getMobile() | setMobile(Phone2 mobile) |
| `Addresses` | [`List<CreateAddressRequest>`](../../doc/models/create-address-request.md) | Optional | - | List<CreateAddressRequest> getAddresses() | setAddresses(List<CreateAddressRequest> addresses) |
| `RegistrationSucceededCallbackUrl` | `String` | Optional | - | String getRegistrationSucceededCallbackUrl() | setRegistrationSucceededCallbackUrl(String registrationSucceededCallbackUrl) |
| `RegistrationOrigin` | `String` | Optional | - | String getRegistrationOrigin() | setRegistrationOrigin(String registrationOrigin) |
| `MarketingAgreement` | `Boolean` | Optional | - | Boolean getMarketingAgreement() | setMarketingAgreement(Boolean marketingAgreement) |
| `Newsletter` | `Boolean` | Optional | - | Boolean getNewsletter() | setNewsletter(Boolean newsletter) |

## Example (as JSON)

```json
{
  "password": "password2",
  "username": "username2",
  "salutation": "salutation2",
  "firstname": "firstname6",
  "lastname": "lastname8"
}
```

