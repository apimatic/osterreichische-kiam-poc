
# Confirm Registration Request

## Structure

`ConfirmRegistrationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Token` | `String` | Optional | - | String getToken() | setToken(String token) |
| `ApplicationName` | `String` | Optional | - | String getApplicationName() | setApplicationName(String applicationName) |

## Example (as JSON)

```json
{
  "token": "token4",
  "applicationName": "applicationName6"
}
```

