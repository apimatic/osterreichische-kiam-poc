
# Phone 2

## Structure

`Phone2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountryCode` | `String` | Optional | - | String getCountryCode() | setCountryCode(String countryCode) |
| `AreaCode` | `String` | Optional | - | String getAreaCode() | setAreaCode(String areaCode) |
| `Number` | `String` | Optional | - | String getNumber() | setNumber(String number) |

## Example (as JSON)

```json
{
  "countryCode": "countryCode0",
  "areaCode": "areaCode6",
  "number": "number8"
}
```

