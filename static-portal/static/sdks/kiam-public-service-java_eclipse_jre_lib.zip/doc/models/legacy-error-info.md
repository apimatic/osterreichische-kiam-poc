
# Legacy Error Info

## Structure

`LegacyErrorInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Code` | `String` | Optional | - | String getCode() | setCode(String code) |
| `Message` | `String` | Optional | - | String getMessage() | setMessage(String message) |
| `Target` | `String` | Optional | - | String getTarget() | setTarget(String target) |
| `Data` | [`List<LegacyErrorData>`](../../doc/models/legacy-error-data.md) | Optional | - | List<LegacyErrorData> getData() | setData(List<LegacyErrorData> data) |

## Example (as JSON)

```json
{
  "code": "code8",
  "message": "message0",
  "target": "target8",
  "data": [
    {
      "name": "name0",
      "value": "value2"
    }
  ]
}
```

